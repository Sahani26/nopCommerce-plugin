﻿using Microsoft.AspNetCore.Routing;
using Nop.Services.Customers;
using Nop.Services.Plugins;
using Nop.Web.Framework.Menu;
using System.Linq;
using System.Threading.Tasks;

namespace Nop.Plugin.Widgets.PrintCustomers
{
    public class PrintCustomersPlugin : BasePlugin, IAdminMenuPlugin
    {
        private readonly ICustomerService _customerService;

        public PrintCustomersPlugin(ICustomerService customerService)
        {
            _customerService = customerService;
        }

        public override string GetConfigurationPageUrl()
        {
            return "/Admin/PrintCustomers/Index";
        }

        public async Task ManageSiteMapAsync(SiteMapNode rootNode)
        {
            var menuItem = new SiteMapNode()
            {
                SystemName = "PrintCustomers",
                Title = "Print Customers",
                ControllerName = "PrintCustomers",
                ActionName = "Index",
                Visible = true,
                RouteValues = new RouteValueDictionary { { "area", "Admin" } },
            };

            var pluginNode = rootNode.ChildNodes.FirstOrDefault(x => x.SystemName == "Miscellaneous");
            if (pluginNode != null)
                pluginNode.ChildNodes.Add(menuItem);
            else
                rootNode.ChildNodes.Add(menuItem);
        }

        public override Task InstallAsync()
        {
            return base.InstallAsync();
        }

        public override Task UninstallAsync()
        {
            return base.UninstallAsync();
        }
    }
}
