﻿using DocumentFormat.OpenXml.Drawing.Charts;
using Microsoft.AspNetCore.Mvc;
using Nop.Services.Customers;
using Nop.Web.Framework.Controllers;
using System.Linq;
using System.Threading.Tasks;

namespace Nop.Plugin.Widgets.PrintCustomers.Controllers
{
    [Route("Admin/PrintCustomers")]
    public class PrintCustomersController : BasePluginController
    {
        private readonly ICustomerService _customerService;

        public PrintCustomersController(ICustomerService customerService)
        {
            _customerService = customerService;
        }

        [HttpGet("Index")]
        public async Task<IActionResult> Index()
        {
            var customers = (await _customerService.GetAllCustomersAsync()).Select(c => c.Email).ToList();
            return View("~/Plugins/Widgets.PrintCustomers/Views/PrintCustomers/Index.cshtml", customers);
        }
    }
}
