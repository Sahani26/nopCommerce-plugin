﻿using Irony.Parsing;
using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Misc.RecentViewProducts.Services;
using Nop.Services.Catalog;
using Nop.Web.Areas.Admin.Models.Catalog;
using Nop.Web.Factories;
using Nop.Web.Framework.Components;

namespace Nop.Plugin.Misc.RecentViewProducts.Components
{
    public class ProductViewComponent : NopViewComponent
    {
        private readonly IProductService _productService;
        private readonly IProductModelFactory _productModelFactory;
        private readonly IProductViewService _productViewService;

        public ProductViewComponent(IProductModelFactory productModelFactory, IProductService productService, IProductViewService productViewService)
        {
            _productModelFactory = productModelFactory;
            _productService = productService;
            _productViewService = productViewService;
        }


        public async Task<IViewComponentResult> InvokeAsync(string widgetZone, object additionalData)
        {
            // Get products
            var products = await _productService.SearchProductsAsync();

            // Prepare ProductOverviewModel
            var model = (await _productModelFactory.PrepareProductOverviewModelsAsync(products)).ToList();

            // Pass the correct model to the view
            return View("~/Plugins/Misc.RecentViewProducts/Views/Products/MyProducts.cshtml", model);
        }

    }
}