﻿using Nop.Data;
using Nop.Plugin.Misc.RecentViewProducts.Domain;
using Nop.Services.Catalog;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.RecentViewProducts.Services
{
    public class ProductViewService : IProductViewService
    {
        private readonly IRepository<ProductViewRecord> _productViewRepository;
        private readonly ICategoryService _categoryService;
        private readonly IProductService _productService;

        public ProductViewService(IProductService productService,
            ICategoryService categoryService,
            IRepository<ProductViewRecord> productViewRepository)
        {
            _productService = productService;
            _categoryService = categoryService;
            _productViewRepository = productViewRepository;
        }




        public async Task LogProductViewAsync(int productId)
        {
            Console.WriteLine($"[DEBUG] Product ID received: {productId}");

            var record = await _productViewRepository.Table
                .FirstOrDefaultAsync(p => p.ProductId == productId);

            if (record != null)
            {
                record.ViewCount++;
                Console.WriteLine($"[DEBUG] Updated ViewCount: {record.ViewCount}");
                await _productViewRepository.UpdateAsync(record);
            }
            else
            {
                Console.WriteLine("[DEBUG] Creating new ProductViewRecord...");
                await _productViewRepository.InsertAsync(new ProductViewRecord
                {
                    ProductId = productId,
                    ViewCount = 1
                });
            }
        }


        public async Task UpdateViewCountAsync(int productId)
        {
            // Check if a record exists for the given productId
            var existingRecord = await _productViewRepository.Table
                .FirstOrDefaultAsync(x => x.ProductId == productId);

            if (existingRecord != null)
            {
                // If record exists, increment the view count
                existingRecord.ViewCount++;
                await _productViewRepository.UpdateAsync(existingRecord);
            }
            else
            {
                // If no record exists, create a new one
                var newRecord = new ProductViewRecord
                {
                    ProductId = productId,
                    ViewCount = 1
                };
                await _productViewRepository.InsertAsync(newRecord);
            }
        }

        /* public async Task<IList<ProductViewRecord>> GetMostViewedProductsAsync(int count)
         {
             return await _productViewRepository.Table
                 .OrderByDescending(p => p.ViewCount)
                 .Take(count) 

                 .ToListAsync();
         }*/
        public async Task<IList<ProductViewRecord>> GetMostViewedProductsAsync(int count)
        {
            // Group by ProductId to ensure we only count each product once per customer
            var result = await _productViewRepository.Table
                .GroupBy(r => r.ProductId) // Group by ProductId to ensure each product is counted once per customer
                .Select(g => new
                {
                    ProductId = g.Key,
                    ViewCount = g.Count() // Count how many different customers viewed this product
                })
                .OrderByDescending(p => p.ViewCount) // Order by view count in descending order
                .Take(count) // Take the top 'count' products
                .ToListAsync();

            // Now, we need to map this result back to the ProductViewRecord object
            var productViewRecords = result.Select(r => new ProductViewRecord
            {
                ProductId = r.ProductId,
                ViewCount = r.ViewCount
            }).ToList();

            return productViewRecords;
        }


        /*   public async Task<IList<int>> GetMostViewedProductsAsync(int count)
           {
               // Get distinct ProductIds without ViewCount
               var productIds = await _productViewRepository.Table
                   .GroupBy(r => r.ProductId) // Group by ProductId
                   .Select(g => g.Key) // Select only ProductId
                   .Take(count) // Get top 'count' products
                   .ToListAsync();

               return productIds;
           }*/

        public async Task RecordProductViewAsync(int productId, int customerId , int manufactureId, int categoryId)
        {
            // Check if there's already a record for this ProductId and CustomerId combination
            var record = await _productViewRepository.Table
                .FirstOrDefaultAsync(r => r.ProductId == productId && r.CustomerId == customerId && r.ManufactureId == manufactureId && r.CategoryId == categoryId);

            if (record == null)
            {
                // If no record exists for the current customer, create a new record with ViewCount = 1
                record = new ProductViewRecord
                {
                    ProductId = productId,
                    CustomerId = customerId, 
                    ManufactureId= manufactureId,
                    CategoryId= categoryId,
                    ViewCount = 1
                };
                await _productViewRepository.InsertAsync(record);
            }
            else
            {
                // If the record exists, do nothing (the view count is not incremented)
                return; // Prevent further processing if the customer has already viewed the product
            }

            // Now, check if there are any records for this ProductId with other CustomerIds
            var productViews = await _productViewRepository.Table
                .Where(r => r.ProductId == productId && r.CustomerId != customerId)
                .ToListAsync();

            // If there are views by different customers, increment the ViewCount
            if (productViews.Any())
            {
                var productView = productViews.FirstOrDefault();
                if (productView != null)
                {
                    productView.ViewCount++; // Increment the view count
                    await _productViewRepository.UpdateAsync(productView);
                }
            }
        }


        // Other methods...

        //public async Task<IList<ProductViewRecord>> GetMostViewedProductsByCategoryAsync(int count, int categoryId)
        //{
        //    // Step 1: Get products in the specified category using SearchProductsAsync
        //    var productsInCategory = await _productService.SearchProductsAsync(
        //        pageIndex: 0,
        //        pageSize: int.MaxValue,
        //        categoryIds: new List<int> { categoryId });


        //    if (productsInCategory == null || !productsInCategory.Any())
        //        return new List<ProductViewRecord>();

        //    // Step 2: Get product view counts for the products in the category
        //    var productViews = await _productViewRepository.Table
        //        .Where(r => productsInCategory.Any(p => p.Id == r.ProductId)) // Filter by ProductId from the category
        //        .GroupBy(r => r.ProductId)
        //        .Select(g => new
        //        {
        //            ProductId = g.Key,
        //            ViewCount = g.Count()
        //        })
        //        .OrderByDescending(p => p.ViewCount)
        //        .Take(count)
        //        .ToListAsync();

        //    // Step 3: Map results back to ProductViewRecord
        //    var productViewRecords = productViews.Select(pv => new ProductViewRecord
        //    {
        //        ProductId = pv.ProductId,
        //        ViewCount = pv.ViewCount
        //    }).ToList();

        //    return productViewRecords;
        //}



    }
}