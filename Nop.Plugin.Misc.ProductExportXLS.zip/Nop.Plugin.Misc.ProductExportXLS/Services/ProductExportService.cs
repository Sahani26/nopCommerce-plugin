﻿using Nop.Services.Catalog;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.ProductExportXLS.Services
{
    public class ProductExportService
    {
        private readonly IProductService _productService;

        public ProductExportService(IProductService productService)
        {
            _productService = productService;
        }

        public async Task<byte[]> ExportProductsToCsvAsync()
        {
            var products = await _productService.SearchProductsAsync();

            var sb = new StringBuilder();
            sb.AppendLine("Product ID,Name,Price,Stock Quantity");

            foreach (var product in products)
            {
                sb.AppendLine($"{product.Id},\"{product.Name}\",{product.Price.ToString(CultureInfo.InvariantCulture)},{product.StockQuantity}");
            }

            return Encoding.UTF8.GetBytes(sb.ToString());
        }
    }
}
