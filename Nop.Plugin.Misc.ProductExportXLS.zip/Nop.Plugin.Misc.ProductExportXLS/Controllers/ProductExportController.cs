﻿using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Misc.ProductExportXLS.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.ProductExportXLS.Controllers
{
    [Route("Admin/ProductExport")]
    public class ProductExportController : Controller
    {
        private readonly ProductExportService _productExportService;

        public ProductExportController(ProductExportService productExportService)
        {
            _productExportService = productExportService;
        }

        [HttpGet("Export")]
        public async Task<IActionResult> Export()
        {
            var csvBytes = await _productExportService.ExportProductsToCsvAsync();
            return File(csvBytes, "text/csv", "products.csv");
        }
    }
}
