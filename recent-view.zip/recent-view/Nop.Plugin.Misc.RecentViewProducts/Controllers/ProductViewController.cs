﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Misc.RecentViewProducts.Services;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc.Filters;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.RecentViewProducts.Controllers
{
    [AllowAnonymous]
    [Route("ProductView")]
    public class ProductViewController : BasePluginController
    {
        private readonly IProductViewService _productViewService;

        public ProductViewController(IProductViewService productViewService)
        {
            _productViewService = productViewService;
        }

        [HttpPost("Log")]
        public async Task<IActionResult> LogProductView(int productId)
        {
            if (productId <= 0)
                return BadRequest("Invalid product ID");

            Console.WriteLine($"Logging view for Product ID: {productId}");

            await _productViewService.LogProductViewAsync(productId);

            return Ok(new { success = true, message = "Product view logged successfully" });
        }
    }

}

