﻿
using Nop.Plugin.Misc.RecentViewProducts.Domain;
 
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.RecentViewProducts.Services
{
    public interface IProductViewService
    {
        Task LogProductViewAsync(int productId);
        Task<IList<ProductViewRecord>> GetMostViewedProductsAsync(int count);

        
    }
}
 