﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nop.Core.Infrastructure;
using Nop.Plugin.Misc.RecentViewProducts.Services;

namespace Nop.Plugin.Misc.RecentViewProducts.Infrastructure
{
    public class NopStartup : INopStartup
    {
   /*     public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IProductViewService, ProductViewService>();
            Console.WriteLine("ProductViewService registered successfully");
        }*/

        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IProductViewService, ProductViewService>();
        }

        public void Configure(IApplicationBuilder application)
        {
            // No middleware needed for this service
        }

        public int Order => 1001; // Ensure it's a high value so it executes after core services
    }
}
