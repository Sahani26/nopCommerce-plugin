﻿using DocumentFormat.OpenXml.EMMA;
using DocumentFormat.OpenXml.Wordprocessing;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Customers;
using Nop.Plugin.Pickup.PickupInStoreNew.Domain;
using Nop.Plugin.Pickup.PickupInStoreNew.Models;
using Nop.Plugin.Pickup.PickupInStoreNew.Services;
using Nop.Services.Catalog;
using Nop.Services.Localization;
using Nop.Services.Media;
using Nop.Services.Stores;
using Nop.Web.Areas.Admin.Factories;
using Nop.Web.Areas.Admin.Models.Catalog;
using Nop.Web.Framework.Models.Extensions; 

namespace Nop.Plugin.Pickup.PickupInStoreNew.Factories
{
    public class StorePickupPointModelFactoryNew:IStorePickupPointModelFactoryNew
    {
        protected readonly IStorePickupPointServiceNew _storePickupPointServiceNew;
        protected readonly ILocalizationService _localizationService;
        protected readonly IStoreService _storeService;
        protected readonly IProductService _productService;
        protected readonly ISettingModelFactory _settingModelFactory;
        protected readonly IPictureService _pictureService;

        public StorePickupPointModelFactoryNew(IStorePickupPointServiceNew storePickupPointServiceNew, ILocalizationService localizationService, IStoreService storeService, IProductService productService, ISettingModelFactory settingModelFactory, IPictureService pictureService)
        {
            _storePickupPointServiceNew = storePickupPointServiceNew;
            _localizationService = localizationService;
            _storeService = storeService;
            _productService = productService;
            _settingModelFactory = settingModelFactory;
            _pictureService = pictureService;
        }

        //show all product 
        //public async Task<StorePickupPointListModelNew> PrepareStorePickupPointListModelAsync(StorePickupPointSearchModelNew searchModel)
        //{
        //    var pickupPoints = await _storePickupPointServiceNew.GetAllStorePickupPointsAsync(pageIndex: searchModel.Page - 1,
        //        pageSize: searchModel.PageSize);
        //    var model = await new StorePickupPointListModelNew().PrepareToGridAsync(searchModel, pickupPoints, () =>
        //    {
        //        return pickupPoints.SelectAwait(async point =>
        //        {
        //            var store = await _storeService.GetStoreByIdAsync(point.StoreId);
        //            // ✅ Get product details to access SKU
        //            var product = await _productService.GetProductByIdAsync(point.ProductId);

        //            return new StorePickupPointModelNew
        //            {
        //                Id = point.Id,
        //                ProductId = point.ProductId,
        //                ViewCount = point.ViewCount,
        //                CustomerId= point.CustomerId,
        //                CategoryId=point.CategoryId,
        //                ProductSku = product?.Sku, // Add SKU here
        //                ProductName = product?.Name,



        //                StoreName = store?.Name
        //                            ?? (point.StoreId == 0 ? (await _localizationService.GetResourceAsync("Admin.Configuration.Settings.StoreScope.AllStores")) : string.Empty)
        //            };
        //        });
        //    });

        //    return model;
        //}
        //sshow sing le product
        public async Task<StorePickupPointListModelNew> PrepareStorePickupPointListModelAsync(StorePickupPointSearchModelNew searchModel)
        {
            var pickupPoints = await _storePickupPointServiceNew.GetAllStorePickupPointsAsync(pageIndex: searchModel.Page - 1,
                pageSize: searchModel.PageSize);

            // ✅ Group by ProductId and take the record with the highest ViewCount
            var highestViewPoints = pickupPoints
                .GroupBy(point => point.ProductId)
                .Select(group => group.OrderByDescending(p => p.ViewCount).First())
                .ToList();

            // ✅ Explicitly specify the type arguments here
            var model = await ModelExtensions.PrepareToGridAsync<StorePickupPointListModelNew, StorePickupPointModelNew, StorePickupPointNew>(
                new StorePickupPointListModelNew(),
                searchModel,
                highestViewPoints.ToPagedList(searchModel),
                () => highestViewPoints.ToAsyncEnumerable().SelectAwait(async point =>
                {
                    var store = await _storeService.GetStoreByIdAsync(point.StoreId);
                    var product = await _productService.GetProductByIdAsync(point.ProductId);



                    /*  // ✅ Prepare picture models

                      var productPictures = await _productService.GetProductPicturesByProductIdAsync(product.Id) ;
                      var productPictureModels = await productPictures
                          .SelectAwait(async productPicture => new ProductPictureModel
                          {
                              Id = productPicture.Id,
                              ProductId = productPicture.ProductId,
                              PictureId = productPicture.PictureId,
                              PictureUrl = await _pictureService.GetPictureUrlAsync(productPicture.PictureId),
                              DisplayOrder = productPicture.DisplayOrder
                          }).ToListAsync();
  */
                    // ✅ Prepare picture models
                    // ✅ Prepare picture models
                    var pictureUrl = string.Empty;

                    if (product != null)
                    {
                        var productPictures = await _productService.GetProductPicturesByProductIdAsync(product.Id);
                        var firstPicture = productPictures.FirstOrDefault();

                        if (firstPicture != null)
                        {
                            pictureUrl = await _pictureService.GetPictureUrlAsync(firstPicture.PictureId, targetSize: 100);
                            Console.WriteLine($"Picture URL for ProductId {product.Id}: {pictureUrl}");
                        }
                        else
                        {
                            Console.WriteLine($"No pictures found for ProductId {product.Id}");
                        }
                    }
                    else
                    {
                        Console.WriteLine($"Product not found for ProductId: {point.ProductId}");
                    }

                    // ✅ Return the model with all properties
                    return new StorePickupPointModelNew
                    {
                        Id = point.Id,
                        ProductId = point.ProductId,
                        ViewCount = point.ViewCount,
                        CustomerId = point.CustomerId,
                        CategoryId = point.CategoryId,
                        ProductSku = product?.Sku ?? string.Empty,
                        ProductName = product?.Name ?? string.Empty,
                        //ProductPictureModels = productPictureModels,
                        PictureThumbnailUrl = pictureUrl, // ✅ Correct URL assignment
                        StoreName = store?.Name
                            ?? (point.StoreId == 0 ? (await _localizationService.GetResourceAsync("Admin.Configuration.Settings.StoreScope.AllStores")) : string.Empty)
                    };
                })
            );

            return model;
        }

        public Task<StorePickupPointSearchModelNew> PrepareStorePickupPointSearchModelAsync(StorePickupPointSearchModelNew searchModel)
        {
            ArgumentNullException.ThrowIfNull(searchModel);

            //prepare page parameters
            searchModel.SetGridPageSize();

            return Task.FromResult(searchModel);
        }
    }
}
