﻿/*using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nop.Core.Infrastructure;
using Nop.Plugin.Pickup.PickupInStoreNew.Controllers;
using Nop.Plugin.Pickup.PickupInStoreNew.Factories;
using Nop.Plugin.Pickup.PickupInStoreNew.Services;
using Nop.Web.Areas.Admin.Controllers;

namespace Nop.Plugin.Pickup.PickupInStoreNew.Infrastructure
{
    public class NopStartup : INopStartup
    {

        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IStorePickupPointServiceNew, StorePickupPointServiceNew>();
            services.AddScoped<IStorePickupPointModelFactoryNew, StorePickupPointModelFactoryNew>();

            // If PickupProductViewController is inheriting from ProductController
            services.AddScoped<ProductController, PickupProductViewController>();


        }

        public void Configure(IApplicationBuilder application)
        {
        }

        public int Order => 3000;
    }
}
*/
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nop.Core.Infrastructure;
// Import your custom controller
using Nop.Plugin.Pickup.PickupInStoreNew.Controllers;
using Nop.Plugin.Pickup.PickupInStoreNew.Factories;
using Nop.Plugin.Pickup.PickupInStoreNew.Services;
using Nop.Web.Controllers;


namespace Nop.Plugin.Pickup.PickupInStoreNew.Infrastructure
{

    public class NopStartup : INopStartup
    {

        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IStorePickupPointServiceNew, StorePickupPointServiceNew>();
            services.AddScoped<IStorePickupPointModelFactoryNew, StorePickupPointModelFactoryNew>();

            // If PickupProductViewController is inheriting from ProductController
            services.AddScoped<ProductController, PickupProductViewController>();


        }

        public void Configure(IApplicationBuilder application)
        {
        }

        public int Order => 3000;
    }

}