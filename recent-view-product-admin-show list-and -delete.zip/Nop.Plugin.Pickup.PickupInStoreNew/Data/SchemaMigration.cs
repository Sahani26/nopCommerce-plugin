﻿using FluentMigrator;
using Nop.Data.Extensions;
using Nop.Data.Migrations;
using Nop.Plugin.Pickup.PickupInStoreNew.Domain;

namespace Nop.Plugin.Pickup.PickupInStoreNew.Data;

[NopMigration("2021/03/03 09:30:17:6455422", "Pickup.PickupInStoreNew base schema", MigrationProcessType.Installation)]
public class SchemaMigration : AutoReversingMigration
{
    public override void Up()
    {
        Create.TableFor<StorePickupPointNew>();
    }
}