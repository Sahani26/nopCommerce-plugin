﻿using Nop.Plugin.Pickup.PickupInStoreNew.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Pickup.PickupInStoreNew.Factories
{
    public interface IStorePickupPointModelFactoryNew
    {
        Task<StorePickupPointListModelNew> PrepareStorePickupPointListModelAsync(StorePickupPointSearchModelNew searchModel);
        Task<StorePickupPointSearchModelNew> PrepareStorePickupPointSearchModelAsync(StorePickupPointSearchModelNew searchModel);
    }
}

