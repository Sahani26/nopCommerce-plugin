﻿using DocumentFormat.OpenXml.EMMA;
using Nop.Core.Domain.Customers;
using Nop.Plugin.Pickup.PickupInStoreNew.Models;
using Nop.Plugin.Pickup.PickupInStoreNew.Services;
using Nop.Services.Catalog;
using Nop.Services.Localization;
using Nop.Services.Stores;
using Nop.Web.Framework.Models.Extensions; 
namespace Nop.Plugin.Pickup.PickupInStoreNew.Factories
{
    public class StorePickupPointModelFactoryNew:IStorePickupPointModelFactoryNew
    {
        protected readonly IStorePickupPointServiceNew _storePickupPointServiceNew;
        protected readonly ILocalizationService _localizationService;
        protected readonly IStoreService _storeService;
        protected readonly IProductService _productService;

        public StorePickupPointModelFactoryNew(IStorePickupPointServiceNew storePickupPointServiceNew, ILocalizationService localizationService, IStoreService storeService, IProductService productService)
        {
            _storePickupPointServiceNew = storePickupPointServiceNew;
            _localizationService = localizationService;
            _storeService = storeService;
            _productService = productService;
        }

        public async Task<StorePickupPointListModelNew> PrepareStorePickupPointListModelAsync(StorePickupPointSearchModelNew searchModel)
        {
            var pickupPoints = await _storePickupPointServiceNew.GetAllStorePickupPointsAsync(pageIndex: searchModel.Page - 1,
                pageSize: searchModel.PageSize);
            var model = await new StorePickupPointListModelNew().PrepareToGridAsync(searchModel, pickupPoints, () =>
            {
                return pickupPoints.SelectAwait(async point =>
                {
                    var store = await _storeService.GetStoreByIdAsync(point.StoreId);
                    // ✅ Get product details to access SKU
                    var product = await _productService.GetProductByIdAsync(point.ProductId);

                    return new StorePickupPointModelNew
                    {
                        Id = point.Id,
                        ProductId = point.ProductId,
                        ViewCount = point.ViewCount,
                        CustomerId= point.CustomerId,
                        CategoryId=point.CategoryId,
                        ProductSku = product?.Sku, // Add SKU here
                        ProductName = product?.Name,
                        StoreName = store?.Name
                                    ?? (point.StoreId == 0 ? (await _localizationService.GetResourceAsync("Admin.Configuration.Settings.StoreScope.AllStores")) : string.Empty)
                    };
                });
            });

            return model;
        }

        public Task<StorePickupPointSearchModelNew> PrepareStorePickupPointSearchModelAsync(StorePickupPointSearchModelNew searchModel)
        {
            ArgumentNullException.ThrowIfNull(searchModel);

            //prepare page parameters
            searchModel.SetGridPageSize();

            return Task.FromResult(searchModel);
        }
    }
}
