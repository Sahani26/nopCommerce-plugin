﻿
using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Pickup.PickupInStoreNew.Services;
using Nop.Services.Catalog;
using Nop.Services.Topics;
using Nop.Web.Factories;
using Nop.Web.Framework.Components;
using Nop.Web.Models.Catalog;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Nop.Plugin.Pickup.PickupInStoreNew.Components
{
    public class CategoryViewComponent :NopViewComponent
    {
        private readonly IProductService _productService;
        private readonly IProductModelFactory _productModelFactory;  
        private readonly ICategoryService _categoryService;
        private readonly IStorePickupPointServiceNew _storePickupPointServiceNew;

        public CategoryViewComponent(IProductService productService, IProductModelFactory productModelFactory, ICategoryService categoryService, IStorePickupPointServiceNew storePickupPointServiceNew)
        {
            _productService = productService;
            _productModelFactory = productModelFactory;
            _categoryService = categoryService;
            _storePickupPointServiceNew = storePickupPointServiceNew;
        }

        public async Task<IViewComponentResult> InvokeAsync(string widgetZone, object additionalData)
        {
            // Get all categories
            var categories = await _categoryService.GetAllCategoriesAsync();
            var categoryProducts = new Dictionary<int, IList<ProductOverviewModel>>();

            foreach (var category in categories)
            {
                // Get most viewed products for each category
                var mostViewedRecords = await _storePickupPointServiceNew.GetMostViewedProductsAsync(5, category.Id);

                if (!mostViewedRecords.Any())
                    continue; // Skip categories with no most viewed products

                var products = await _productService.GetProductsByIdsAsync(mostViewedRecords.Select(p => p.ProductId).ToArray());

                if (!products.Any())
                    continue; // Skip categories where no valid products were found

                var model = (await _productModelFactory.PrepareProductOverviewModelsAsync(products)).ToList();
                categoryProducts[category.Id] = model;
            }

            // If no categories have products, return an empty view
            if (!categoryProducts.Any())
                return Content(string.Empty);

            return View("~/Plugins/Pickup.PickupInStoreNew/Views/Category/CategoryProducts.cshtml", categoryProducts);
        }
    }
}
 