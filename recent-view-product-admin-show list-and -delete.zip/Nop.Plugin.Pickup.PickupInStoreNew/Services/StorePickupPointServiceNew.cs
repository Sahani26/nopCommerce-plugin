﻿using Nop.Core;
using Nop.Core.Caching;
using Nop.Data;
using Nop.Plugin.Pickup.PickupInStoreNew.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Pickup.PickupInStoreNew.Services
{
    public class StorePickupPointServiceNew: IStorePickupPointServiceNew
    {
        protected readonly CacheKey _pickupPointAllKey = new("Nop.pickuppoint.all-{0}", PICKUP_POINT_PATTERN_KEY);
        protected const string PICKUP_POINT_PATTERN_KEY = "Nop.pickuppoint.";

        protected readonly IRepository<StorePickupPointNew> _storePickupPointRepository;
        protected readonly IShortTermCacheManager _shortTermCacheManager;
        protected readonly IStaticCacheManager _staticCacheManager;
        public StorePickupPointServiceNew(IRepository<StorePickupPointNew> storePickupPointRepository,
      IShortTermCacheManager shortTermCacheManager,
      IStaticCacheManager staticCacheManager)
        {
            _storePickupPointRepository = storePickupPointRepository;
            _shortTermCacheManager = shortTermCacheManager;
            _staticCacheManager = staticCacheManager;
        }

        public virtual async Task<IPagedList<StorePickupPointNew>> GetAllStorePickupPointsAsync(int storeId = 0, int pageIndex = 0, int pageSize = int.MaxValue)
        {
            var rez = await _shortTermCacheManager.GetAsync(async () => await _storePickupPointRepository.GetAllAsync(query =>
            {
                if (storeId > 0)
                    query = query.Where(point => point.StoreId == storeId || point.StoreId == 0);
                query = query.OrderBy(point => point.DisplayOrder).ThenBy(point => point.Name);

                return query;
            }), _pickupPointAllKey, storeId);

            return new PagedList<StorePickupPointNew>(rez, pageIndex, pageSize);
        }
        /*   public virtual async Task<StorePickupPointNew> GetStorePickupPointByIdAsync(int pickupPointId)
           {
               return await _storePickupPointRepository.GetByIdAsync(pickupPointId);
           }*/
        public virtual async Task<StorePickupPointNew> GetStorePickupPointByIdAsync(int pickupPointId)
        {
            Console.WriteLine($"[DEBUG] Fetching pickup point with ID: {pickupPointId}");

            var pickupPoint = await _storePickupPointRepository.GetByIdAsync(pickupPointId);

            if (pickupPoint == null)
            {
                Console.WriteLine($"[ERROR] No pickup point found with ID: {pickupPointId}");
            }
            else
            {
                Console.WriteLine($"[SUCCESS] Pickup point found: ID = {pickupPoint.Id}, Name = {pickupPoint.Name}");
            }

            return pickupPoint;
        }

        public virtual async Task InsertStorePickupPointAsync(StorePickupPointNew pickupPoint)
        {
            await _storePickupPointRepository.InsertAsync(pickupPoint, false);
            await _staticCacheManager.RemoveByPrefixAsync(PICKUP_POINT_PATTERN_KEY);
        }
        public virtual async Task UpdateStorePickupPointAsync(StorePickupPointNew pickupPoint)
        {
            await _storePickupPointRepository.UpdateAsync(pickupPoint, false);
            await _staticCacheManager.RemoveByPrefixAsync(PICKUP_POINT_PATTERN_KEY);
        }
        public virtual async Task DeleteStorePickupPointAsync(StorePickupPointNew pickupPoint)
        {
            await _storePickupPointRepository.DeleteAsync(pickupPoint, false);
            await _staticCacheManager.RemoveByPrefixAsync(PICKUP_POINT_PATTERN_KEY);
        }


        public async Task RecordProductViewAsync(int productId, int customerId, int categoryId)
        {
            // Check if there's already a record for this ProductId and CustomerId combination
            var record = await _storePickupPointRepository.Table
                .FirstOrDefaultAsync(r => r.ProductId == productId && r.CustomerId == customerId && r.CategoryId == categoryId);

            if (record == null)
            {
                // If no record exists for the current customer, create a new record with ViewCount = 1
                record = new StorePickupPointNew
                {
                    ProductId = productId,
                    CustomerId = customerId,

                    CategoryId = categoryId,
                    ViewCount = 1
                };
                await _storePickupPointRepository.InsertAsync(record);
            }
            else
            {
                // If the record exists, do nothing (the view count is not incremented)
                return; // Prevent further processing if the customer has already viewed the product
            }

            // Now, check if there are any records for this ProductId with other CustomerIds
            var productViews = await _storePickupPointRepository.Table
                .Where(r => r.ProductId == productId && r.CustomerId != customerId)
                .ToListAsync();

            // If there are views by different customers, increment the ViewCount
            if (productViews.Any())
            {
                var productView = productViews.FirstOrDefault();
                if (productView != null)
                {
                    productView.ViewCount++; // Increment the view count
                    await _storePickupPointRepository.UpdateAsync(productView);
                }
            }
        }


        public async Task<IList<StorePickupPointNew>> GetMostViewedProductsAsync(int count, int categoryId)
        {
            // Group by ProductId and CategoryId to ensure we count views for each product in the specified category
            var result = await _storePickupPointRepository.Table
                .Where(r => r.CategoryId == categoryId) // Filter by the specified categoryId
                .GroupBy(r => r.ProductId) // Group by ProductId to count views per product
                .Select(g => new
                {
                    ProductId = g.Key, // The ProductId is the key of the group
                    ViewCount = g.Count() // Count how many views for this product
                })
                .OrderByDescending(p => p.ViewCount) // Order by view count in descending order
                .Take(count) // Take the top 'count' most viewed products
                .ToListAsync();

            // Map the result to a list of ProductViewRecord objects
            var productViewRecords = result.Select(r => new StorePickupPointNew
            {
                ProductId = r.ProductId,
                ViewCount = r.ViewCount,
                // Assuming ProductName, CategoryName, etc. need to be fetched, you can fetch these values here.
                // Example (if they are in another service or repo):
                // ProductName = await _productRepository.GetProductNameById(r.ProductId),
                // CategoryName = await _categoryRepository.GetCategoryNameById(categoryId),
            }).ToList();

            return productViewRecords;
        }
    }
}
