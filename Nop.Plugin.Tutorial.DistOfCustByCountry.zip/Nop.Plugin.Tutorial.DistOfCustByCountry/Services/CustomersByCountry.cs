﻿using Nop.Plugin.Tutorial.DistOfCustByCountry.Models;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Directory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Tutorial.DistOfCustByCountry.Services
{
    public class CustomersByCountry : ICustomersByCountry
    {
        private readonly IAddressService _addressService;
        private readonly ICountryService _countryService;
        private readonly ICustomerService _customerService;

        public CustomersByCountry(IAddressService addressService,
            ICountryService countryService,
            ICustomerService customerService)
        {
            _addressService = addressService;
            _countryService = countryService;
            _customerService = customerService;
        }
 
        public async Task<List<CustomersDistribution>> GetCustomersDistributionByCountryAsync()
        {
            var customers = await _customerService.GetAllCustomersAsync();
            return await customers.Where(c => c.ShippingAddressId != null)
                .SelectAwait(async c => new
                {
                    (await _countryService.GetCountryByAddressAsync(await _addressService.GetAddressByIdAsync(c.ShippingAddressId ?? 0))).Name,
                    c.Username
                })
                .GroupBy(c => c.Name)
                .SelectAwait(async cbc => new CustomersDistribution
                {
                    Country = cbc.Key,
                    NoOfCustomers = await cbc.CountAsync()
                }).ToListAsync();
        }

    }
}
