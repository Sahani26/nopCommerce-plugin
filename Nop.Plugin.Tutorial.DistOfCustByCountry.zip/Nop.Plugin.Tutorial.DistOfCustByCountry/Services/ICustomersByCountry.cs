﻿using Nop.Plugin.Tutorial.DistOfCustByCountry.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Tutorial.DistOfCustByCountry.Services
{
    public interface ICustomersByCountry
    {
        Task<List<CustomersDistribution>> GetCustomersDistributionByCountryAsync();
}
}
