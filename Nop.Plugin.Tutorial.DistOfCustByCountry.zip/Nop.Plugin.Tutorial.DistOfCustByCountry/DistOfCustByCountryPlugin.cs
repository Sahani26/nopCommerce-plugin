﻿using Nop.Core;
using Nop.Services.Cms;
using Nop.Services.Configuration;
using Nop.Services.Plugins;
using Nop.Web.Framework.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Tutorial.DistOfCustByCountry
{
    public class DistOfCustByCountryPlugin : BasePlugin
    {
        protected readonly IWebHelper _webHelper;
        private readonly ISettingService _settingService;

        public DistOfCustByCountryPlugin(IWebHelper webHelper, ISettingService settingService)
        {
            _webHelper = webHelper;
            _settingService = settingService;
        }

        public override string GetConfigurationPageUrl()
        {
            return _webHelper.GetStoreLocation() + "Admin/DistOfCustByCountryPlugin/Configure";
        }

        public override async Task InstallAsync()
        {
            // You can save default settings if needed
            await base.InstallAsync();
        }

        public override async Task UninstallAsync()
        {
            // Remove settings if needed
            await base.UninstallAsync();
        }
    }
}
