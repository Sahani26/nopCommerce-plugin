﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nop.Core.Infrastructure;
using Nop.Plugin.Tutorial.DistOfCustByCountry.Services;

namespace Nop.Plugin.Tutorial.DistOfCustByCountry
{
    public class Startup : INopStartup
    {
        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            // Register your service
            services.AddScoped<ICustomersByCountry, CustomersByCountry>();
        }

        public void Configure(IApplicationBuilder application)
        {
            // No middleware setup needed for this plugin
        }

        public int Order => 1; // Define execution order
    }
}
