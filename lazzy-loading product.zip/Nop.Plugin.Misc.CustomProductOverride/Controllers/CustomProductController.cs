﻿using Microsoft.AspNetCore.Mvc;
using Nop.Services.Catalog;
using Nop.Web.Controllers;
using Nop.Web.Factories;
using Nop.Web.Framework.Components;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.CustomProductOverride.Controllers
{
    public class CustomProductController: ProductController
    {
        private readonly IProductService _productService;
        private readonly IProductModelFactory _productModelFactory;

        public CustomProductController(IProductService productService, IProductModelFactory productModelFactory)
            : base(productService, productModelFactory)
        {
            _productService = productService;
            _productModelFactory = productModelFactory;
        }
        [HttpPost]
        [IgnoreAntiforgeryToken]
        public async Task<IActionResult> LoadMoreProducts([FromBody] int[] productIds)
        {
            try
            {
                if (productIds == null || !productIds.Any())
                {
                    Console.WriteLine("❌ No product IDs provided.");
                    return BadRequest("No product IDs provided.");
                }

                Console.WriteLine($"✅ Received product IDs: {string.Join(",", productIds)}");

                var products = await _productService.GetProductsByIdsAsync(productIds);

                if (!products.Any())
                {
                    return NotFound("No products found.");
                }

                var model = (await _productModelFactory.PrepareProductOverviewModelsAsync(products)).ToList();

                return PartialView("~/Plugins/Misc.CustomProductOverride/Views/Shared/_ProductBoxList.cshtml", model);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error: {ex.Message}");
                return BadRequest($"Error: {ex.Message}");
            }
        }
    }
}
