﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nop.Core.Infrastructure;
using Nop.Web.Framework.Mvc.Routing;

namespace Nop.Plugin.Misc.CustomProductOverride
{
    public class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(IEndpointRouteBuilder routeBuilder)
        {
            routeBuilder.MapControllerRoute(
                name: "LoadMoreProducts",
                pattern: "LoadMoreProducts",
                defaults: new { controller = "CustomProduct", action = "LoadMoreProducts" });
        }

        public int Priority => 0;
    }

    public class CustomProductOverrideStartup : INopStartup
    {
        public void Configure(IApplicationBuilder application)
        {
            // No custom middleware
        }

        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
        }

        public int Order => 0;
    }
}
