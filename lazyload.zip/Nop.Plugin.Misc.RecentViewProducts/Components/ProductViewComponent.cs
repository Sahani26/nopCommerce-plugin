﻿using Microsoft.AspNetCore.Mvc;
using Nop.Services.Catalog;
using Nop.Web.Factories;
using Nop.Web.Framework.Components;
using Nop.Web.Models.Catalog;
using System.Linq;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.RecentViewProducts.Components
{
    public class ProductViewComponent : NopViewComponent
    {
        private readonly IProductService _productService;
        private readonly IProductModelFactory _productModelFactory;

        public ProductViewComponent(
            IProductService productService,
            IProductModelFactory productModelFactory)
        {
            _productService = productService;
            _productModelFactory = productModelFactory;
        }

        /// <summary>
        /// Load initial products and return paged results
        /// </summary>
        public async Task<IViewComponentResult> InvokeAsync(string widgetZone, object additionalData, int pageNumber = 1, int pageSize = 8)

        {
            // Get paginated products
            var products = await _productService.SearchProductsAsync(pageIndex: pageNumber - 1, pageSize: pageSize);

            // Prepare ProductOverviewModel
            var model = (await _productModelFactory.PrepareProductOverviewModelsAsync(products)).ToList();

            // Pass model and page number to the view
            ViewBag.PageNumber = pageNumber;
            ViewBag.HasMoreProducts = products.TotalCount > pageNumber * pageSize;

            // Return view for ViewComponent
            return View("~/Plugins/Misc.RecentViewProducts/Views/Products/MyProducts.cshtml", model);
        }
    }
}
