﻿/*var pageNumber = 1;
var hasMoreProducts = true;
var isLoading = false;

function loadMoreProducts() {
    if (!hasMoreProducts || isLoading) {
        console.log('No more products to load or already loading...');
        return;
    }

    isLoading = true; // ✅ Set loading to true to prevent multiple requests

    // ✅ Increment page number before calling AJAX
    pageNumber++;

    $.ajax({
        url: '/Product/LoadMoreProducts',
        type: 'GET',
        data: { pageNumber: pageNumber, pageSize: 4 }, // ✅ Set pageSize to 4 as per your requirement
        success: function (data) {
            if (data.trim() === '') {
                hasMoreProducts = false;
                $('#load-more-btn').hide(); // ✅ Hide button when no more products
                console.log('No more products available.');
                stopAutoReload(); // ✅ Stop auto-reloading if no more products
            } else {
                $('#product-container .item-grid').append(data);
                console.log('✅ Products loaded. Page Number:', pageNumber);
            }
        },
        error: function (xhr, status, error) {
            console.error('❌ Error loading more products:', error);
            // ✅ Reset pageNumber if error occurs
            pageNumber--;
        },
        complete: function () {
            isLoading = false; // ✅ Reset loading status after completion
        }
    });
}



*/

var pageNumber = @ViewBag.PageNumber;
var hasMoreProducts = @((bool)ViewBag.HasMoreProducts ? "true" : "false");
var isLoading = false;

function loadMoreProducts() {
    if (!hasMoreProducts || isLoading) {
        console.log('No more products to load or already loading...');
        return;
    }

    isLoading = true;
    $('#loading-indicator').show(); // ✅ Show loading indicator

    $.ajax({
        url: '/Product/LoadMoreProducts',
        type: 'GET',
        data: { pageNumber: pageNumber + 1, pageSize: 8 }, // ✅ Updated pageSize to 8
        success: function (data) {
            console.log('Data length:', data.length);

            if (data.trim() === '') {
                hasMoreProducts = false;
                $('#load-more-btn').hide();
                console.log('No more products available.');
            } else {
                $('#product-container .item-grid').append(data);
                pageNumber++;
                console.log('✅ Products loaded. Page Number:', pageNumber);
            }
        },
        error: function () {
            console.error('❌ Error loading more products.');
        },
        complete: function () {
            isLoading = false;
            $('#loading-indicator').hide(); // ✅ Hide loading indicator after request
        }
    });
}

// ✅ Detect scroll and auto load next 8 products
$(window).on('scroll', function () {
    if (isLoading) return;

    var scrollPosition = $(window).scrollTop() + $(window).height();
    var scrollHeight = $(document).height();
    var distanceFromBottom = scrollHeight - scrollPosition;

    console.log('Scroll Position:', scrollPosition, 'Scroll Height:', scrollHeight);

    // ✅ Load when user is within 10% from the bottom
    if (distanceFromBottom <= (scrollHeight * 0.25)) {
        console.log('Near the bottom - loading more products');
        loadMoreProducts();
    }
});

// ✅ Button Click to Load More Products
$('#load-more-btn').on('click', function () {
    loadMoreProducts();
});
