﻿using Microsoft.AspNetCore.Mvc;
using Nop.Services.Catalog;
using Nop.Web.Factories;
using Nop.Web.Models.Catalog;
using System.Linq;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.RecentViewProducts.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductService _productService;
        private readonly IProductModelFactory _productModelFactory;

        public ProductController(
            IProductService productService,
            IProductModelFactory productModelFactory)
        {
            _productService = productService;
            _productModelFactory = productModelFactory;
        }

        /// <summary>
        /// Show initial list of 8 products
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> MyProducts(int pageNumber = 1, int pageSize = 8)

        {
            // Get paginated products
            var products = await _productService.SearchProductsAsync(pageIndex: pageNumber - 1, pageSize: pageSize);

            // Prepare ProductOverviewModel
            var model = (await _productModelFactory.PrepareProductOverviewModelsAsync(products)).ToList();

            // Pass model and page number to the view
            ViewBag.PageNumber = pageNumber;
            ViewBag.HasMoreProducts = products.TotalCount > pageNumber * pageSize;

            // Return view for initial products
            return View("~/Plugins/Misc.RecentViewProducts/Views/Products/MyProducts.cshtml", model);
        }
        [HttpGet]



        /// <summary>
        /// Load next 8 products on button click
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> LoadMoreProducts(int pageNumber, int pageSize = 8)

        {
            // Get next paginated products
            var products = await _productService.SearchProductsAsync(pageIndex: pageNumber - 1, pageSize: pageSize);

            // Prepare ProductOverviewModel
            var model = (await _productModelFactory.PrepareProductOverviewModelsAsync(products)).ToList();

            // Return empty if no more products
            if (!model.Any())
                return Content(string.Empty);

            // Return partial view for next batch of products
            return PartialView("~/Plugins/Misc.RecentViewProducts/Views/Products/_ProductListPartial.cshtml", model);
        }
    }
}
