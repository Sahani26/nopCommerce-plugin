﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Nop.Web.Framework.Mvc.Routing;

namespace Nop.Plugin.Misc.RecentViewProducts
{
    public class RouteProvider : IRouteProvider
    {
        /// <summary>
        /// Register custom routes for the plugin.
        /// </summary>
        public void RegisterRoutes(IEndpointRouteBuilder endpointRouteBuilder)
        {
            // Route to load more products
            endpointRouteBuilder.MapControllerRoute(
                name: "LoadMoreProducts",
                pattern: "Plugins/Misc.RecentViewProducts/LoadMoreProducts",
                defaults: new { controller = "Product", action = "LoadMoreProducts" }
            );

            // Route to display initial 8 products
            endpointRouteBuilder.MapControllerRoute(
                name: "MyProducts",
                pattern: "Plugins/Misc.RecentViewProducts/MyProducts",
                defaults: new { controller = "Product", action = "MyProducts" }
            );
        }

        /// <summary>
        /// Route priority, lower values are executed first
        /// </summary>
        public int Priority => -1; // Set priority to ensure it's loaded early
    }
}
