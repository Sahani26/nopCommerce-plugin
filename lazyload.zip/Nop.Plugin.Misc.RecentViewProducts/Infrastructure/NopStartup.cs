﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nop.Core.Infrastructure;
using Nop.Plugin.Misc.RecentViewProducts.Controllers; // Import your custom controller
using Nop.Web.Controllers;

namespace Nop.Plugin.Misc.RecentViewProducts.Infrastructure
{
    public class NopStartup : INopStartup
    {
        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            // Override the default ProductController with our custom one
           /* services.AddScoped<ProductController, ProductViewController>();*/
        }

        public void Configure(IApplicationBuilder application)
        {
            // No middleware needed
        }

        public int Order => 1001; // Ensures it runs after core services
    }
}
