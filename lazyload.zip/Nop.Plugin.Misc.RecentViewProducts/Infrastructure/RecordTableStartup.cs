﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nop.Core.Infrastructure;
using Nop.Plugin.Misc.RecentViewProducts.Services;

namespace Nop.Plugin.Misc.RecentViewProducts.Infrastructure
{
    public class RecordTableStartup : INopStartup
    {
        public int Order => 2000;

        public void Configure(IApplicationBuilder application)
        {
            // No middleware required here
        }

        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            // Register services needed for the plugin
            services.AddScoped<IProductViewService, ProductViewService>();
        }

        /// <summary>
        /// Register routes when application starts
        /// </summary>
        public void ConfigureRoutes(IEndpointRouteBuilder routeBuilder)
        {
            routeBuilder.MapControllerRoute(
                name: "LoadMoreProducts",
                pattern: "Plugins/Misc.RecentViewProducts/LoadMoreProducts",
                defaults: new { controller = "Product", action = "LoadMoreProducts" }
            );

            routeBuilder.MapControllerRoute(
                name: "MyProducts",
                pattern: "Plugins/Misc.RecentViewProducts/MyProducts",
                defaults: new { controller = "Product", action = "MyProducts" }
            );
        }
    }
}
