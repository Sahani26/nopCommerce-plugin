﻿using Nop.Core;
using Nop.Plugin.Misc.RecentViewProducts.Components;
using Nop.Services.Cms;
using Nop.Services.Plugins;
using Nop.Web.Framework.Infrastructure;

namespace Nop.Plugin.Misc.RecentViewProducts
{
    public class RecentVIewProductPlugin : BasePlugin, IWidgetPlugin

    {
        private readonly IWebHelper _webHelper;

        public RecentVIewProductPlugin(IWebHelper webHelper)
        {
            _webHelper = webHelper;
        }

        public bool HideInWidgetList => false;
      

        public Task<IList<string>> GetWidgetZonesAsync()
        {
            return Task.FromResult<IList<string>>(new List<string> {/* PublicWidgetZones.HomepageBeforeCategories,*/PublicWidgetZones.HomepageBeforeNews   });
        }
        public Type GetWidgetViewComponent(string widgetZone)
        {
         /*   if (widgetZone.Equals(PublicWidgetZones.HomepageBeforeCategories)  )
                return typeof(CategoryViewComponent);*/

            if (widgetZone.Equals(PublicWidgetZones.HomepageBeforeNews))
                return typeof(ProductViewComponent);

            return null;

        }

        public override Task InstallAsync()
        {
            return base.InstallAsync();
        }
        public override Task UninstallAsync() {     return base.UninstallAsync(); }
    }
}
