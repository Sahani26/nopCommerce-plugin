﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nop.Core.Infrastructure;
using Nop.Plugin.Misc.MostViewProduct.Controllers;
using Nop.Plugin.Misc.MostViewProduct.Factories;
using Nop.Plugin.Misc.MostViewProduct.Services;
using Nop.Web.Controllers;

namespace Nop.Plugin.Misc.MostViewProduct.Infrastructure
{
    public class NopStartup : INopStartup
    {


    

        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<ProductController, MostviewController>();
            services.AddScoped<IMostViewService, MostViewService>();
            services.AddScoped<IMostViewModelFactory, MostViewModelFactory>();
        }
        public void Configure(IApplicationBuilder application)
        {

        }
        public int Order => 1001;
    }
}
