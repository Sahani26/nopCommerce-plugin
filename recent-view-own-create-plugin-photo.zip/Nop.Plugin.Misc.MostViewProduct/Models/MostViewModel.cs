﻿using Nop.Web.Areas.Admin.Models.Catalog;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.MostViewProduct.Models
{
    public record MostViewModel :BaseNopEntityModel
    {
        [NopResourceDisplayName("Plugins.Misc.MostViewProduct.Fields.ProductId")]
        public int ProductId { get; set; }
        [NopResourceDisplayName("Plugins.Misc.MostViewProduct.Fields.ViewCount")]
        public int ViewCount { get; set; }
        [NopResourceDisplayName("Plugins.Misc.MostViewProduct.Fields.CustomerId")]
        public int CustomerId { get; set; }
        [NopResourceDisplayName("Plugins.Misc.MostViewProduct.Fields.CategoryId")]
        public int CategoryId { get; set; }
        [NopResourceDisplayName("Plugins.Misc.MostViewProduct.Fields.Name")]
        public string Name { get; set; }
        [NopResourceDisplayName("Plugins.Misc.MostViewProduct.Fields.StoreName")]
        public int StoreName { get; set; }
        public string PictureThumbnailUrl { get; set; } = string.Empty;
        public IList<ProductPictureModel> ProductPictureModels { get; set; } = new List<ProductPictureModel>();
        [NopResourceDisplayName("Plugins.Misc.MostViewProduct.Fields.ProductSku")]
        public string ProductSku { get; set; } // Add
                                               // 
        [NopResourceDisplayName("Plugins.Misc.MostViewProduct.Fields.ProductName")]
        public string ProductName { get; set; } // Add this

    }
}
