﻿using Nop.Core;
using Nop.Services.Localization;
using Nop.Services.Plugins;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.MostViewProduct
{
    public class MostViewProductPlugin :BasePlugin
    {
        protected readonly IWebHelper _webHelper;
/*        protected readonly ILocalizationService _localizationService;*/

        public MostViewProductPlugin(IWebHelper webHelper/*, ILocalizationService localizationService*/)
        {
            _webHelper = webHelper;
          /*  _localizationService = localizationService;*/
        }

        public override string GetConfigurationPageUrl()
        {
            return $"{_webHelper.GetStoreLocation()}Admin/Most/Configure";
        }

        public override async Task InstallAsync()
        {
            //locales
        /*    await _localizationService.AddOrUpdateLocaleResourceAsync(new Dictionary<string, string>
            {
                ["Plugins.Misc.MostViewProduct.Fields.ProductId"] = "ProductId",
                ["Plugins.Misc.MostViewProduct.Fields.ViewCount"] = " ViewCount",
                 ["Plugins.Misc.MostViewProduct.Fields.CustomerId"] = "CustomerId",
                 ["Plugins.Misc.MostViewProduct.Fields.CategoryId"] = " CategoryId",
                 ["Plugins.Misc.MostViewProduct.Fields.Name"] = "Name",
                 ["Plugins.Misc.MostViewProduct.Fields.StoreName "] = "StoreName",
                 ["Plugins.Misc.MostViewProduct.Fields.ProductSku "] = "ProductSku",
                 ["Plugins.Misc.MostViewProduct.Fields.ProductName "] = " ProductName",
               
               
            });
*/
            await base.InstallAsync();
        }
        public override Task UninstallAsync() { 
            
            
            
            return base.UninstallAsync(); }
    }
}
