﻿using Nop.Core;

namespace Nop.Plugin.Misc.MostViewProduct.Domain
{
    public class MostRecord :BaseEntity
    {
        public int ProductId { get; set; }
        public int ViewCount { get; set; }
        public int CustomerId { get; set; }
        public int CategoryId { get; set; }
        public string Name { get; set; }

    }
}
