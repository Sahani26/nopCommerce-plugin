﻿using Nop.Plugin.Misc.MostViewProduct.Domain;
using Nop.Plugin.Misc.MostViewProduct.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.MostViewProduct.Factories
{
    public interface IMostViewModelFactory
    {
        Task<MostViewListModel> PrepareStorePickupPointListModelAsync(MostViewSearchModel searchModel);
        Task<MostViewSearchModel> PrepareStorePickupPointSearchModelAsync(MostViewSearchModel searchModel);  // Corrected return type to MostViewSearchModel
    }
}
