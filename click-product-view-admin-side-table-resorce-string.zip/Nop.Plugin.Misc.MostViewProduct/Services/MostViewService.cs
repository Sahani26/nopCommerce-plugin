﻿using Nop.Core;
using Nop.Core.Caching;
using Nop.Data;
using Nop.Plugin.Misc.MostViewProduct.Domain;
using Nop.Services.Catalog;

namespace Nop.Plugin.Misc.MostViewProduct.Services
{
    public class MostViewService :IMostViewService
    {
        protected readonly CacheKey _pickupPointAllKey = new("Nop.pickuppoint.all-{0}", PICKUP_POINT_PATTERN_KEY);
        protected const string PICKUP_POINT_PATTERN_KEY = "Nop.pickuppoint.";
        private readonly IRepository<MostRecord> _productViewRepository;
        private readonly ICategoryService _categoryService;
        private readonly IProductService _productService;
        protected readonly IShortTermCacheManager _shortTermCacheManager;
        protected readonly IStaticCacheManager _staticCacheManager;

        public MostViewService(IRepository<MostRecord> productViewRepository, ICategoryService categoryService, IProductService productService, IShortTermCacheManager shortTermCacheManager, IStaticCacheManager staticCacheManager)
        {
            _productViewRepository = productViewRepository;
            _categoryService = categoryService;
            _productService = productService;
            _shortTermCacheManager = shortTermCacheManager;
            _staticCacheManager = staticCacheManager;
        }

        public async Task RecordProductViewAsync(int productId, int customerId, int categoryId)
        {
            // Check if there's already a record for this ProductId and CustomerId combination
            var record = await _productViewRepository.Table
                .FirstOrDefaultAsync(r => r.ProductId == productId && r.CustomerId == customerId && r.CategoryId == categoryId);

            if (record == null)
            {
                // If no record exists for the current customer, create a new record with ViewCount = 1
                record = new MostRecord
                {
                    ProductId = productId,
                    CustomerId = customerId,

                    CategoryId = categoryId,
                    ViewCount = 1
                };
                await _productViewRepository.InsertAsync(record);
            }
            else
            {
                // If the record exists, do nothing (the view count is not incremented)
                return; // Prevent further processing if the customer has already viewed the product
            }

            // Now, check if there are any records for this ProductId with other CustomerIds
            var productViews = await _productViewRepository.Table
                .Where(r => r.ProductId == productId && r.CustomerId != customerId)
                .ToListAsync();

            // If there are views by different customers, increment the ViewCount
            if (productViews.Any())
            {
                var productView = productViews.FirstOrDefault();
                if (productView != null)
                {
                    productView.ViewCount++; // Increment the view count
                    await _productViewRepository.UpdateAsync(productView);
                }
            }
        }

        public virtual async Task<IPagedList<MostRecord>> GetAllStorePickupPointsAsync(int pageIndex = 0, int pageSize = int.MaxValue)
        {
            var rez = await _shortTermCacheManager.GetAsync(async () =>
                await _productViewRepository.GetAllAsync(query =>
                {
                    // Removed the sorting by DisplayOrder, now sorting only by Name
                    query = query.OrderBy(point => point.Name);

                    return query;
                }),
                _pickupPointAllKey
            );

            // Return the paged result
            return new PagedList<MostRecord>(rez, pageIndex, pageSize);
        }
        public virtual async Task<MostRecord> GetStorePickupPointByIdAsync(int Id)
        {
            return await _productViewRepository.GetByIdAsync(Id);
        }

        public virtual async Task DeleteStorePickupPointAsync(MostRecord pickupPoint)
        {
            await _productViewRepository.DeleteAsync(pickupPoint, false);
            await _staticCacheManager.RemoveByPrefixAsync(PICKUP_POINT_PATTERN_KEY);
        }

    }
}
