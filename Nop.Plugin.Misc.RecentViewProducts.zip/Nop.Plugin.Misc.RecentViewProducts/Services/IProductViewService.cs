﻿
using Nop.Plugin.Misc.RecentViewProducts.Domain;
 
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.RecentViewProducts.Services
{
    public interface IProductViewService
    {
        Task LogProductViewAsync(int productId);
        Task<IList<ProductViewRecord>> GetMostViewedProductsAsync(int count, int categoryId);
        Task RecordProductViewAsync(int productId, int customerId,  int categoryId);

        // New method to get most viewed products by category
        //Task<IList<ProductViewRecord>> GetMostViewedProductsByCategoryAsync(int count, int categoryId);
        
          
        Task<IList<ProductViewRecord>> GetCategoryIdAsync( int categoryId);



    }
}
 