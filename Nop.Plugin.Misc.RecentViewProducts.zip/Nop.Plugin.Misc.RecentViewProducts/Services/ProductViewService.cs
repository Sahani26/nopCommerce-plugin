﻿using Nop.Data;
using Nop.Plugin.Misc.RecentViewProducts.Domain;
using Nop.Services.Catalog;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.RecentViewProducts.Services
{
    public class ProductViewService : IProductViewService
    {
        private readonly IRepository<ProductViewRecord> _productViewRepository;
        private readonly ICategoryService _categoryService;
        private readonly IProductService _productService;

        public ProductViewService(IProductService productService,
            ICategoryService categoryService,
            IRepository<ProductViewRecord> productViewRepository)
        {
            _productService = productService;
            _categoryService = categoryService;
            _productViewRepository = productViewRepository;
        }




        public async Task LogProductViewAsync(int productId)
        {
            Console.WriteLine($"[DEBUG] Product ID received: {productId}");

            var record = await _productViewRepository.Table
                .FirstOrDefaultAsync(p => p.ProductId == productId);

            if (record != null)
            {
                record.ViewCount++;
                Console.WriteLine($"[DEBUG] Updated ViewCount: {record.ViewCount}");
                await _productViewRepository.UpdateAsync(record);
            }
            else
            {
                Console.WriteLine("[DEBUG] Creating new ProductViewRecord...");
                await _productViewRepository.InsertAsync(new ProductViewRecord
                {
                    ProductId = productId,
                    ViewCount = 1
                });
            }
        }


        public async Task UpdateViewCountAsync(int productId)
        {
            // Check if a record exists for the given productId
            var existingRecord = await _productViewRepository.Table
                .FirstOrDefaultAsync(x => x.ProductId == productId);

            if (existingRecord != null)
            {
                // If record exists, increment the view count
                existingRecord.ViewCount++;
                await _productViewRepository.UpdateAsync(existingRecord);
            }
            else
            {
                // If no record exists, create a new one
                var newRecord = new ProductViewRecord
                {
                    ProductId = productId,
                    ViewCount = 1
                };
                await _productViewRepository.InsertAsync(newRecord);
            }
        }



        public async Task<IList<ProductViewRecord>> GetMostViewedProductsAsync(int count, int categoryId)
        {
            // Group by ProductId and CategoryId to ensure we count views for each product in the specified category
            var result = await _productViewRepository.Table
                .Where(r => r.CategoryId == categoryId) // Filter by the specified categoryId
                .GroupBy(r => r.ProductId) // Group by ProductId to count views per product
                .Select(g => new
                {
                    ProductId = g.Key, // The ProductId is the key of the group
                    ViewCount = g.Count() // Count how many views for this product
                })
                .OrderByDescending(p => p.ViewCount) // Order by view count in descending order
                .Take(count) // Take the top 'count' most viewed products
                .ToListAsync();

            // Map the result to a list of ProductViewRecord objects
            var productViewRecords = result.Select(r => new ProductViewRecord
            {
                ProductId = r.ProductId,
                ViewCount = r.ViewCount,
                // Assuming ProductName, CategoryName, etc. need to be fetched, you can fetch these values here.
                // Example (if they are in another service or repo):
                // ProductName = await _productRepository.GetProductNameById(r.ProductId),
                // CategoryName = await _categoryRepository.GetCategoryNameById(categoryId),
            }).ToList();

            return productViewRecords;
        }


        public async Task RecordProductViewAsync(int productId, int customerId , int categoryId)
        {
            // Check if there's already a record for this ProductId and CustomerId combination
            var record = await _productViewRepository.Table
                .FirstOrDefaultAsync(r => r.ProductId == productId && r.CustomerId == customerId &&  r.CategoryId == categoryId);

            if (record == null)
            {
                // If no record exists for the current customer, create a new record with ViewCount = 1
                record = new ProductViewRecord
                {
                    ProductId = productId,
                    CustomerId = customerId, 
                  
                    CategoryId= categoryId,
                    ViewCount = 1
                };
                await _productViewRepository.InsertAsync(record);
            }
            else
            {
                // If the record exists, do nothing (the view count is not incremented)
                return; // Prevent further processing if the customer has already viewed the product
            }

            // Now, check if there are any records for this ProductId with other CustomerIds
            var productViews = await _productViewRepository.Table
                .Where(r => r.ProductId == productId && r.CustomerId != customerId)
                .ToListAsync();

            // If there are views by different customers, increment the ViewCount
            if (productViews.Any())
            {
                var productView = productViews.FirstOrDefault();
                if (productView != null)
                {
                    productView.ViewCount++; // Increment the view count
                    await _productViewRepository.UpdateAsync(productView);
                }
            }
        }



        // Fetch the product view records for a given categoryId
        public async Task<IList<ProductViewRecord>> GetCategoryIdAsync(int categoryId)
        {
            // Query the database or repository to fetch the records for the given categoryId
            var records = await _productViewRepository.Table
                .Where(r => r.CategoryId == categoryId)
                .ToListAsync();

            return records; // Return the list of ProductViewRecord objects
        }


    }
}