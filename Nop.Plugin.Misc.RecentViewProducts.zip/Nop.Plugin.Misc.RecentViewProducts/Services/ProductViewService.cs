﻿using Nop.Data;
using Nop.Plugin.Misc.RecentViewProducts.Domain; 
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.RecentViewProducts.Services
{
    public class ProductViewService : IProductViewService
    {
        private readonly IRepository<ProductViewRecord> _productViewRepository;

        public ProductViewService(IRepository<ProductViewRecord> productViewRepository)
        {
            _productViewRepository = productViewRepository;
        }




        public async Task LogProductViewAsync(int productId)
        {
            Console.WriteLine($"[DEBUG] Product ID received: {productId}");

            var record = await _productViewRepository.Table
                .FirstOrDefaultAsync(p => p.ProductId == productId);

            if (record != null)
            {
                record.ViewCount++;
                Console.WriteLine($"[DEBUG] Updated ViewCount: {record.ViewCount}");
                await _productViewRepository.UpdateAsync(record);
            }
            else
            {
                Console.WriteLine("[DEBUG] Creating new ProductViewRecord...");
                await _productViewRepository.InsertAsync(new ProductViewRecord
                {
                    ProductId = productId,
                    ViewCount = 1
                });
            }
        }


        public async Task UpdateViewCountAsync(int productId)
        {
            // Check if a record exists for the given productId
            var existingRecord = await _productViewRepository.Table
                .FirstOrDefaultAsync(x => x.ProductId == productId);

            if (existingRecord != null)
            {
                // If record exists, increment the view count
                existingRecord.ViewCount++;
                await _productViewRepository.UpdateAsync(existingRecord);
            }
            else
            {
                // If no record exists, create a new one
                var newRecord = new ProductViewRecord
                {
                    ProductId = productId,
                    ViewCount = 1
                };
                await _productViewRepository.InsertAsync(newRecord);
            }
        }

        public async Task<IList<ProductViewRecord>> GetMostViewedProductsAsync(int count)
        {
            return await _productViewRepository.Table
                .OrderByDescending(p => p.ViewCount)
                .Take(count) 
                 
                .ToListAsync();
        }
        public async Task RecordProductViewAsync(int productId)
        {
            var record = await _productViewRepository.Table
                .FirstOrDefaultAsync(r => r.ProductId == productId);

            if (record != null)
            {
                record.ViewCount++;
                await _productViewRepository.UpdateAsync(record);
            }
            else
            {
                record = new ProductViewRecord
                {
                    ProductId = productId,
                    ViewCount = 1,

                };
                await _productViewRepository.InsertAsync(record);
            }
        }
    }
}