﻿using Nop.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.RecentViewProducts.Domain


{
    public class ProductViewRecord : BaseEntity
    {
        public int ProductId { get; set; }
        public int ViewCount { get; set; }
        public int CustomerId { get; set; }

/*        public int ManufactureId { get; set; }*/
        public int CategoryId { get; set; }

    }
    

     
}
