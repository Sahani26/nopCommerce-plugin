﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nop.Core.Infrastructure;
using Nop.Plugin.Misc.RecentViewProducts.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.RecentViewProducts.Infrastructure
{
    public class RecordTableStartup : INopStartup
    {
        public int Order =>2000;

        public void Configure(IApplicationBuilder application)
        {
            // No additional configuration needed here for routing
        }
        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IProductViewService, ProductViewService>();
            services.Configure<RouteOptions>(options => options.LowercaseUrls = true);
        }

        public void ConfigureRoutes(IEndpointRouteBuilder routeBuilder)
        {
            routeBuilder.MapControllerRoute(
     name: "ProductViewLog",
     pattern: "ProductView/Log",
     defaults: new { controller = "ProductView", action = "Log" }
 );
            routeBuilder.MapControllerRoute(
                           name: "CategoryProducts",
                           pattern: "category-products/{categoryId:int}",
                           defaults: new { controller = "CategoryProduct", action = "CategoryProducts" }
                       );
        }

    }
}
