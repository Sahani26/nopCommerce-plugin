﻿/*using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Misc.RecentViewProducts.Services;
using Nop.Services.Catalog;
using Nop.Web.Factories;
using Nop.Web.Framework.Components;
using System.Linq;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.RecentViewProducts.Components
{
    public class ProductViewComponent : NopViewComponent
    {
        private readonly IProductService _productService;
        private readonly IProductModelFactory _productModelFactory;
        private readonly IProductViewService _productViewService;

        public ProductViewComponent(IProductModelFactory productModelFactory, IProductService productService, IProductViewService productViewService)
        {
            _productModelFactory = productModelFactory;
            _productService = productService;
            _productViewService = productViewService;
        }

        public async Task<IViewComponentResult> InvokeAsync(string widgetZone, object additionalData)
        {
            // Extract the categoryId from the additionalData parameter
            int? categoryId = additionalData as int?;

            if (!categoryId.HasValue)
            {
                // Return an error or handle the case when categoryId is not provided
                return Content("Category ID not provided");
            }

            // Get the most viewed products for the specified categoryId
            var mostViewedRecords = await _productViewService.GetMostViewedProductsAsync(5, categoryId.Value); // Pass both the count and categoryId
            var products = await _productService.GetProductsByIdsAsync(mostViewedRecords.Select(p => p.ProductId).ToArray());

            var model = (await _productModelFactory.PrepareProductOverviewModelsAsync(products)).ToList();
            return View("~/Plugins/Misc.RecentViewProducts/Views/Products/MyProducts.cshtml", model);
        }
    }
}


*//*return View("~/Plugins/Misc.RecentViewProducts/Views/Products/CategoryProducts.cshtml", model);*/