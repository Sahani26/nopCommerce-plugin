﻿/*using DocumentFormat.OpenXml.EMMA;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Misc.RecentViewProducts.Services;
using Nop.Services.Catalog;
using Nop.Web.Factories;
using Nop.Web.Framework.Components;

namespace Nop.Plugin.Misc.RecentViewProducts.Components
{
    public class CategoryViewComponent : NopViewComponent
    {
        private readonly IProductService _productService;
        private readonly IProductModelFactory _productModelFactory;
        private readonly IProductViewService _productViewService;

        public CategoryViewComponent(IProductModelFactory productModelFactory, IProductService productService, IProductViewService productViewService)
        {
            _productModelFactory = productModelFactory;
            _productService = productService;
            _productViewService = productViewService;
        }

        public async Task<IViewComponentResult> InvokeAsync(string widgetZone, object additionalData)
        {

            // Extract categoryId from the additionalData (you can also pass this as a parameter in other ways)
            int? categoryId = additionalData as int?;


            if (!categoryId.HasValue)
            {
                return Content("Category ID not provided");
            }



            // Retrieve the most viewed products for the given categoryId
            var mostViewedRecords = await _productViewService.GetMostViewedProductsAsync(5, categoryId.Value); // Pass categoryId to your service method
            var products = await _productService.GetProductsByIdsAsync(mostViewedRecords.Select(p => p.ProductId).ToArray());

            var model = (await _productModelFactory.PrepareProductOverviewModelsAsync(products)).ToList();
            return View("~/Plugins/Misc.RecentViewProducts/Views/Category/CategoryProducts.cshtml", model);
        }
    }
}
 */


using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Misc.RecentViewProducts.Services;
using Nop.Services.Catalog;
using Nop.Services.Topics;
using Nop.Web.Factories;
using Nop.Web.Framework.Components;
using Nop.Web.Models.Catalog;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.RecentViewProducts.Components
{
    public class CategoryViewComponent : NopViewComponent
    {
        private readonly IProductService _productService;
        private readonly IProductModelFactory _productModelFactory;
        private readonly IProductViewService _productViewService;
        private readonly ICategoryService _categoryService;

        public CategoryViewComponent(IProductModelFactory productModelFactory, IProductService productService, IProductViewService productViewService, ICategoryService categoryService)
        {
            _productModelFactory = productModelFactory;
            _productService = productService;
            _productViewService = productViewService;
            _categoryService = categoryService;
        }

    

        public async Task<IViewComponentResult> InvokeAsync(string widgetZone, object additionalData)
        {
            // Get all categories
            var categories = await _categoryService.GetAllCategoriesAsync();
            var categoryProducts = new Dictionary<int, IList<ProductOverviewModel>>();

            foreach (var category in categories)
            {
                // Get most viewed products for each category
                var mostViewedRecords = await _productViewService.GetMostViewedProductsAsync(5, category.Id);

                if (!mostViewedRecords.Any())
                    continue; // Skip categories with no most viewed products

                var products = await _productService.GetProductsByIdsAsync(mostViewedRecords.Select(p => p.ProductId).ToArray());

                if (!products.Any())
                    continue; // Skip categories where no valid products were found

                var model = (await _productModelFactory.PrepareProductOverviewModelsAsync(products)).ToList();
                categoryProducts[category.Id] = model;
            }

            // If no categories have products, return an empty view
            if (!categoryProducts.Any())
                return Content(string.Empty);

            return View("~/Plugins/Misc.RecentViewProducts/Views/Category/CategoryProducts.cshtml", categoryProducts);
        }

    }
}
