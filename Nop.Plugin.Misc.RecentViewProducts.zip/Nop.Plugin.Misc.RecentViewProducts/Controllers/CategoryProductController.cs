﻿/*using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Misc.RecentViewProducts.Services;
using Nop.Services.Catalog;
using Nop.Web.Factories;
using Nop.Web.Framework.Controllers;
using System.Linq;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.RecentViewProducts.Controllers
{
    public class CategoryProductController : BasePluginController
    {
        private readonly IProductService _productService;
        private readonly IProductModelFactory _productModelFactory;
        private readonly IProductViewService _productViewService;

        public CategoryProductController(IProductModelFactory productModelFactory, IProductService productService, IProductViewService productViewService)
        {
            _productModelFactory = productModelFactory;
            _productService = productService;
            _productViewService = productViewService;
        }

        public async Task<IActionResult> CategoryProducts(int categoryId)
        {
            if (categoryId <= 0)
                return NotFound();

            // Retrieve most viewed products for the given category
            var mostViewedRecords = await _productViewService.GetMostViewedProductsAsync(5, categoryId);
            var products = await _productService.GetProductsByIdsAsync(mostViewedRecords.Select(p => p.ProductId).ToArray());

            var model = (await _productModelFactory.PrepareProductOverviewModelsAsync(products)).ToList();
            return View("~/Plugins/Misc.RecentViewProducts/Views/Category/CategoryProducts.cshtml", model);
        }
    }
}
*/