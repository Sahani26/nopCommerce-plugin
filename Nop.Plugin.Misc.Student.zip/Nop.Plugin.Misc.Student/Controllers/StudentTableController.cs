﻿using DocumentFormat.OpenXml.EMMA;
using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Misc.Student.Domain;
using Nop.Plugin.Misc.Student.Models;
using Nop.Plugin.Misc.Student.Services;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.Student.Controllers
{

    [Area(AreaNames.ADMIN)]
    [AuthorizeAdmin]
    [AutoValidateAntiforgeryToken]
    public class StudentTableController : BasePluginController
    {
        private readonly IStudentTableService _studentTableService;

        public StudentTableController(IStudentTableService studentTableService)
        {
            _studentTableService = studentTableService;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var dataFromDb = await _studentTableService.GetAllPropertiesAsync();
            var properties = dataFromDb.Select(x => new StudentTable
            {
                Email = x.Email, // No need for ToString() if it's an int
                Name = x.Name,
                Id = x.Id
            }).ToList();
            return View("~/Plugins/Misc.Student/Views/StudentTable/Index.cshtml", properties);
        }

         


        [HttpGet]
        public IActionResult Create()
        {
            return View("~/Plugins/Misc.Student/Views/StudentTable/Create.cshtml");
        }

        [HttpPost("Admin/StudentTable/Create")]
        public async Task<IActionResult> Create(StudentRecord model)
        {
            if (!ModelState.IsValid)
                return View("~/Plugins/Misc.Student/Views/StudentTable/Create.cshtml", model);

            var studentEntity = new StudentRecord
            {
                Name = model.Name,
                Email = model.Email
            };

            await _studentTableService.InsertAsync(studentEntity);
            return RedirectToAction("Index");
        }


        [HttpGet("{id}")]
        public async Task<IActionResult> Edit(int id)
        {
            var student = await _studentTableService.GetByIdAsync(id);
            if (student == null)
                return NotFound();

            var model = new StudentTable
            {
                Id = student.Id,
                Name = student.Name,
                Email = student.Email
            };

            return View("~/Plugins/Misc.Student/Views/StudentTable/Edit.cshtml", model);
        }

        [HttpPost("{id}")]
        public async Task<IActionResult> Edit(StudentTable model)
        {
            if (!ModelState.IsValid)
                return View("~/Plugins/Misc.Student/Views/StudentTable/Edit.cshtml", model);

            var studentEntity = await _studentTableService.GetByIdAsync(model.Id);
            if (studentEntity == null)
                return NotFound();

            studentEntity.Name = model.Name;
            studentEntity.Email = model.Email;

            await _studentTableService.UpdateAsync(studentEntity);
            return RedirectToAction("Index");
        }
        /*  ---------------delete--------------*/
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            var studentRecord = await _studentTableService.GetByIdAsync(id);

            if (studentRecord == null)
                return NotFound();

            /* return View(studentRecord); // Redirects to a Delete Confirmation View*/
            return View("~/Plugins/Misc.Student/Views/StudentTable/Delete.cshtml", studentRecord);
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var studentRecord = await _studentTableService.GetByIdAsync(id);

            if (studentRecord == null)
                return NotFound();

            await _studentTableService.DeleteAsync(studentRecord);

            return RedirectToAction("Index");
        }


    }
}
