﻿using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Misc.Student.Domain;
using Nop.Plugin.Misc.Student.Models;
using Nop.Plugin.Misc.Student.Services;
using Nop.Web.Framework.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.Student.Components
{
    public class StudentViewComponents :NopViewComponent
    {
        private readonly IStudentTableService _studentTableService;
public StudentViewComponents(IStudentTableService studentTableService)
        {
            _studentTableService = studentTableService;
        }

        public async Task<IViewComponentResult> InvokeAsync(string widgetZone, object additionalData)
        {
            var studentRecords = await _studentTableService.GetAllPropertiesAsync();

            // Convert from domain entity to view model
            var students = studentRecords.Select(s => new StudentTable
            {
                Id = s.Id,
                Name = s.Name,
                Email = s.Email
            }).ToList();

            return View("~/Plugins/Misc.Student/Views/StudentTable/Index.cshtml", students);
        }
    }
}
