﻿using Microsoft.AspNetCore.Mvc;
using Nop.Services.Catalog;
// Explicitly reference the correct IProductModelFactory
using Nop.Web.Factories;
using Nop.Web.Framework.Components;
using Nop.Web.Models.Catalog;
using Nop.Web.Models.Catalog;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Nop.Plugin.Misc.Student.Components
{
    public class ProductViewComponent : NopViewComponent
    {
        private readonly IProductService _productService;
        private readonly Nop.Web.Factories.IProductModelFactory _productModelFactory; // ✅ Explicit reference

        public ProductViewComponent(IProductService productService, Nop.Web.Factories.IProductModelFactory productModelFactory)
        {
            _productService = productService;
            _productModelFactory = productModelFactory;
        }

        public async Task<IViewComponentResult> InvokeAsync(string widgetZone, object additionalData)
        {
            var products = (await _productService.SearchProductsAsync(
                pageIndex: 0,
                pageSize: 10,
                showHidden: false
            )).ToList();

            var model = (await _productModelFactory.PrepareProductOverviewModelsAsync(products,
                productThumbPictureSize: 200,
                forceRedirectionAfterAddingToCart: true)).ToList();

            return View("~/Plugins/Misc.Student/Views/Products/MyProducts.cshtml", model);
        }
    }
}
