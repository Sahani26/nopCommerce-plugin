﻿    using Microsoft.AspNetCore.Routing;
using Nop.Core;
using Nop.Plugin.Misc.Student.Components;
using Nop.Services.Cms;
using Nop.Services.Plugins;
using Nop.Web.Framework.Infrastructure;
using Nop.Web.Framework.Menu;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.Student
{
    public class StudentPlugin :BasePlugin, IAdminMenuPlugin,IWidgetPlugin
    {
        private readonly IWebHelper _webHelper;

        public bool HideInWidgetList => false;

        public StudentPlugin(IWebHelper webHelper)
        {
            _webHelper = webHelper;
        }

        public override string GetConfigurationPageUrl()
        {
          
            return _webHelper.GetStoreLocation() + "Admin/StudentTable/Index";
        }
     

        public async Task ManageSiteMapAsync(SiteMapNode rootNode)
        {
            var menuItem = new SiteMapNode()
            {
                SystemName = "StudentTable",
                Title = "Print Student Data",
                ControllerName = "StudentTable",
                ActionName = "Index",
                Visible = true,
                RouteValues = new RouteValueDictionary { { "area", "Admin" } },
            };

            var pluginNode = rootNode.ChildNodes.FirstOrDefault(x => x.SystemName == "Miscellaneous");
            if (pluginNode != null)
                pluginNode.ChildNodes.Add(menuItem);
            else
                rootNode.ChildNodes.Add(menuItem);
        }
        public override Task InstallAsync()
        {
            return base.InstallAsync();
        }
        public override Task UninstallAsync()
        {
            return base.UninstallAsync();
        }

        public Task<IList<string>> GetWidgetZonesAsync()
        {
            return Task.FromResult<IList<string>>(new List<string> { PublicWidgetZones.HomepageBeforeCategories,"StudentView" ,PublicWidgetZones.HomepageBeforeBestSellers});
        }

        public Type GetWidgetViewComponent(string widgetZone)
        {

            if (widgetZone.Equals(PublicWidgetZones.HomepageBeforeCategories))
            {
                return typeof(StudentViewComponents);
            }
             if (widgetZone.Equals(PublicWidgetZones.HomepageBeforeBestSellers))
            {
                return typeof(ProductViewComponent);
            }

            if (widgetZone.Equals("StudentView"))

            {
                return typeof(StudentViewComponents);
            }

           
            return null;
        }
    }
}
