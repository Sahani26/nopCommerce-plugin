﻿using Nop.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.Student.Domain
{
    public class StudentRecord :BaseEntity
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
