﻿using FluentMigrator;
using Nop.Data.Extensions;
using Nop.Data.Migrations;
using Nop.Plugin.Misc.Student.Domain;

namespace Nop.Plugin.Misc.Student.Data;

[NopMigration("2024/09/26 12:01:00", "Misc.Student base schema", MigrationProcessType.Installation)]
public class SchemaMigration : AutoReversingMigration
{
    #region Methods

    /// <summary>
    /// Collect the UP migration expressions
    /// </summary>
    public override void Up()
    {
        Create.TableFor<StudentRecord>();
    }

    #endregion
}