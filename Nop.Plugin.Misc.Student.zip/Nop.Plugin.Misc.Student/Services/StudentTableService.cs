﻿using Nop.Data;
using Nop.Plugin.Misc.Student.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.Student.Services
{
    public class StudentTableService : IStudentTableService
    {
        private readonly IRepository<StudentRecord> _studentTableService;

        public StudentTableService(IRepository<StudentRecord> studentTableService)
        {
            _studentTableService = studentTableService;
        }


        

        public async Task<List<StudentRecord>> GetAllPropertiesAsync()
        {
            return await Task.FromResult(
              _studentTableService.Table.ToList() // ✅ Return List<CustomNewTable>
          );
        }

        public async Task<StudentRecord> GetByIdAsync(int id)
        {
            return await _studentTableService.GetByIdAsync(id);
        }

        public async Task UpdateAsync(StudentRecord student)
        {
            await _studentTableService.UpdateAsync(student);
        }

        public async Task InsertAsync(StudentRecord customTable)
        {
            await _studentTableService.InsertAsync(customTable);
        }

        public async Task DeleteAsync(StudentRecord student)
        {
            await _studentTableService.DeleteAsync(student);
        }

    }
}
