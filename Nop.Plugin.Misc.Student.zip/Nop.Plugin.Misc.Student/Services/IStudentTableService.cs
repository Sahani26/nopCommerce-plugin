﻿using Nop.Plugin.Misc.Student.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.Student.Services
{
    public interface IStudentTableService
    {
        Task<List<StudentRecord>> GetAllPropertiesAsync(); // ✅ Ensure correct return type
        Task<StudentRecord> GetByIdAsync(int id); // 🔹 Get student by ID
        Task UpdateAsync(StudentRecord student);  // 🔹 Update student record
        Task InsertAsync(StudentRecord customTable); // ✅ New Method
        Task DeleteAsync(StudentRecord student);


    }
}
