﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nop.Core.Infrastructure;
using Nop.Plugin.Misc.Student.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.Student.Infrastructure
{
    public class NopStartup : INopStartup
    {
        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            // ✅ Register your custom service
            services.AddScoped<IStudentTableService, StudentTableService>();
        }
        public void Configure(IApplicationBuilder application)
        {
            // You can add middleware configuration here if needed
        }

        public int Order => 1001; // Plugins usually have a high order value
    }
}
