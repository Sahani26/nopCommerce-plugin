﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nop.Core.Infrastructure;

namespace Nop.Plugin.Misc.Student.Infrastructure
{
    public class StudentTableStartup : INopStartup
    {
        public void Configure(IApplicationBuilder application)
        {
            // No additional configuration needed here for routing
        }

        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            // Register any required services here
        }

        public void ConfigureRoutes(IEndpointRouteBuilder routeBuilder)
        {
            // Register your custom plugin routes with the correct Admin area
            routeBuilder.MapControllerRoute(
                name: "AdminStudentTable",
                pattern: "Admin/StudentTable/Index",
                defaults: new { controller = "StudentTable", action = "Index", area = "Admin" }
            );

            routeBuilder.MapControllerRoute(
                name: "AdminStudentTableEdit",
                pattern: "Admin/StudentTable/Edit/{id?}",
                defaults: new { controller = "StudentTable", action = "Edit", area = "Admin" }
            );

            routeBuilder.MapControllerRoute(
       name: "AdminStudentTableCreate",
       pattern: "Admin/StudentTable/Create",
       defaults: new { controller = "StudentTable", action = "Create" }
   );



            routeBuilder.MapControllerRoute(
    name: "StudentTableDelete",
    pattern: "Admin/StudentTable/Delete/{id?}",
    defaults: new { controller = "StudentTable", action = "Delete" }
);

        }

        public int Order => 2000; // Ensure it loads after core routes
    }
}
