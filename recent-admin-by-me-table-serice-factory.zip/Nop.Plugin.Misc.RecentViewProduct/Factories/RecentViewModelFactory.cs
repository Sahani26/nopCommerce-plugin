﻿using Nop.Plugin.Misc.RecentViewProduct.Domain;
using Nop.Plugin.Misc.RecentViewProduct.Models;
using Nop.Plugin.Misc.RecentViewProduct.Services;
using Nop.Services.Catalog;
using Nop.Services.Localization;
using Nop.Services.Media;
using Nop.Services.Stores;
using Nop.Web.Areas.Admin.Factories;
using Nop.Web.Framework.Models.Extensions;

namespace Nop.Plugin.Misc.RecentViewProduct.Factories
{
    public class RecentViewModelFactory : IRecentViewModelFactory
    {
        private readonly IRecentViewService _recentViewService;
        protected readonly ILocalizationService _localizationService;
        protected readonly IStoreService _storeService;
        protected readonly IProductService _productService;
        protected readonly ISettingModelFactory _settingModelFactory;
        protected readonly IPictureService _pictureService;

        public RecentViewModelFactory(IRecentViewService recentViewService, ILocalizationService localizationService, IStoreService storeService, IProductService productService, ISettingModelFactory settingModelFactory, IPictureService pictureService)
        {
            _recentViewService = recentViewService;
            _localizationService = localizationService;
            _storeService = storeService;
            _productService = productService;
            _settingModelFactory = settingModelFactory;
            _pictureService = pictureService;
        }

        public async Task<RecentViewListModel> PrepareStorePickupPointListModelAsync(RecentSearchModel searchModel)
        {
            var pickupPoints = await _recentViewService.GetAllStorePickupPointsAsync(
                pageIndex: searchModel.Page - 1,
                pageSize: searchModel.PageSize
            );

            // ✅ Group by ProductId and take the record with the highest ViewCount
            var highestViewPoints = pickupPoints
                .GroupBy(point => point.ProductId)
                .Select(group => group.OrderByDescending(p => p.ViewCount).First())
                .ToList();

            var model = await ModelExtensions.PrepareToGridAsync<RecentViewListModel, RecentViewModel, RecentRecord>(
                new RecentViewListModel(),
                searchModel,
                highestViewPoints.ToPagedList(searchModel),
                () => highestViewPoints.ToAsyncEnumerable().SelectAwait(async point =>
                {
                    var product = await _productService.GetProductByIdAsync(point.ProductId);

                    var pictureUrl = string.Empty;

                    if (product != null)
                    {
                        var productPictures = await _productService.GetProductPicturesByProductIdAsync(product.Id);
                        var firstPicture = productPictures.FirstOrDefault();

                        if (firstPicture != null)
                        {
                            pictureUrl = await _pictureService.GetPictureUrlAsync(firstPicture.PictureId, targetSize: 100);
                            Console.WriteLine($"Picture URL for ProductId {product.Id}: {pictureUrl}");
                        }
                        else
                        {
                            Console.WriteLine($"No pictures found for ProductId {product.Id}");
                        }
                    }
                    else
                    {
                        Console.WriteLine($"Product not found for ProductId: {point.ProductId}");
                    }

                    // ✅ Return the model with all properties
                    return new RecentViewModel
                    {
                        Id = point.Id,
                        ProductId = point.ProductId,
                        ViewCount = point.ViewCount,
                        CustomerId = point.CustomerId,
                        CategoryId = point.CategoryId,
                        ProductSku = product?.Sku ?? string.Empty,
                        ProductName = product?.Name ?? string.Empty,
                        PictureThumbnailUrl = pictureUrl,
                    };
                })
            );

            // ✅ Return the final model
            return model;
        }

        public Task<RecentSearchModel> PrepareStorePickupPointSearchModelAsync(RecentSearchModel searchModel)
        {
            ArgumentNullException.ThrowIfNull(searchModel);

            // Prepare page parameters
            searchModel.SetGridPageSize();

            return Task.FromResult(searchModel);
        }
    }
}
