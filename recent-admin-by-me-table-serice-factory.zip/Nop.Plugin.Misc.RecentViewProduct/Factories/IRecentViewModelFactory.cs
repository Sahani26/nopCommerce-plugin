﻿using Nop.Plugin.Misc.RecentViewProduct.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.RecentViewProduct.Factories
{
    public interface IRecentViewModelFactory
    {
        Task<RecentViewListModel> PrepareStorePickupPointListModelAsync(RecentSearchModel searchModel);
        Task<RecentSearchModel> PrepareStorePickupPointSearchModelAsync(RecentSearchModel searchModel);
    }
}
