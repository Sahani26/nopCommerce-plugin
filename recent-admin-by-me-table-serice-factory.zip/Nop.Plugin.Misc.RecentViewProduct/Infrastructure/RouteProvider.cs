﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc.Routing;

namespace Nop.Plugin.Misc.RecentViewProduct.Infrastructure
{
    public class RouteProvider: IRouteProvider
    {
        public void RegisterRoutes(IEndpointRouteBuilder endpointRouteBuilder)
        {
            endpointRouteBuilder.MapControllerRoute(name: "Recent",
                pattern: "Admin/Recent/Configure",
                defaults: new { controller = "Recent", action = "Configure", area = AreaNames.ADMIN });
       /*     endpointRouteBuilder.MapControllerRoute(name: "List",
             pattern: "Admin/Most/Configure",
             defaults: new { controller = "most", action = "List" });*/
        }

        /// <summary>
        /// Gets a priority of route provider
        /// </summary>
        public int Priority => 0;
    }
}
