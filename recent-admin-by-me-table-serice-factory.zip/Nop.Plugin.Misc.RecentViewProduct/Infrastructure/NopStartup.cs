﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nop.Core.Infrastructure;
using Nop.Plugin.Misc.RecentViewProduct.Controllers;
using Nop.Plugin.Misc.RecentViewProduct.Factories;
using Nop.Plugin.Misc.RecentViewProduct.Services;
using Nop.Web.Controllers;

namespace Nop.Plugin.Misc.RecentViewProduct.Infrastructure
{
    public class NopStartup : INopStartup
    {
        public int Order =>     1001;

        public void Configure(IApplicationBuilder application)
        {
          
        }

        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<ProductController, RecentViewController>();
            services.AddScoped<IRecentViewService, RecentViewService>();
            services.AddScoped<IRecentViewModelFactory, RecentViewModelFactory>();
        }
    }
}
