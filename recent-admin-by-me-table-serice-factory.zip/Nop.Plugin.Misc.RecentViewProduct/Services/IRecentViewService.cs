﻿using Nop.Core;
using Nop.Plugin.Misc.RecentViewProduct.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.RecentViewProduct.Services
{
    public interface IRecentViewService
    {
        Task RecordProductViewAsync(int productId, int customerId, int categoryId);
        Task<IPagedList<RecentRecord>> GetAllStorePickupPointsAsync(int pageIndex = 0, int pageSize = int.MaxValue);
 
        Task<RecentRecord> GetRecentRecordproductByIdAsync(int Id);
        Task DeleteStorePickupPointAsync(RecentRecord recentRecord);
    }
}
