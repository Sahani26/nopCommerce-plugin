﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Misc.RecentViewProduct.Models
{
    public record RecentSearchModel: BaseSearchModel
    {
    }
}
