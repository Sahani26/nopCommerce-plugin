﻿using Microsoft.AspNetCore.Mvc;
using Nop.Core.Domain.Common;
using Nop.Plugin.Misc.RecentViewProduct.Factories;
using Nop.Plugin.Misc.RecentViewProduct.Models;
using Nop.Plugin.Misc.RecentViewProduct.Services;
using Nop.Services.Common;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Services.Security;
using Nop.Services.Stores;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc;
using Nop.Web.Framework.Mvc.Filters;

namespace Nop.Plugin.Misc.RecentViewProduct.Controllers
{
    [Area(AreaNames.ADMIN)]
    [AuthorizeAdmin]
    [AutoValidateAntiforgeryToken]
    public class RecentController: BasePluginController
    {
        protected readonly IAddressService _addressService;
        protected readonly ICountryService _countryService;
        protected readonly ILocalizationService _localizationService;
        protected readonly IPermissionService _permissionService;
        protected readonly IStateProvinceService _stateProvinceService;
        protected readonly IStoreService _storeService;
        protected readonly AddressSettings _addressSettings; 
        protected readonly IRecentViewModelFactory _recentViewModelFactory;
        protected readonly IRecentViewService _recentViewService;

        public RecentController(IAddressService addressService, ICountryService countryService, ILocalizationService localizationService,
            IPermissionService permissionService, IStateProvinceService stateProvinceService, IStoreService storeService,
            AddressSettings addressSettings, IRecentViewModelFactory recentViewModelFactory, IRecentViewService recentViewService)
        {
            _addressService = addressService;
            _countryService = countryService;
            _localizationService = localizationService;
            _permissionService = permissionService;
            _stateProvinceService = stateProvinceService;
            _storeService = storeService;
            _addressSettings = addressSettings;
            _recentViewModelFactory = recentViewModelFactory;
            _recentViewService = recentViewService;
        }
        public async Task<IActionResult> Configure()
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManageShippingSettings))
                return AccessDeniedView();
            //prepare model
            //prepare model
            var model = await _recentViewModelFactory.PrepareStorePickupPointSearchModelAsync(new RecentSearchModel());
            return View("~/Plugins/Misc.RecentViewProduct/Views/Configure.cshtml", model);
       

        }
        [HttpPost]
        public async Task<IActionResult> List(RecentSearchModel searchModel)
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManageShippingSettings))
                return await AccessDeniedDataTablesJson();

            var model = await _recentViewModelFactory.PrepareStorePickupPointListModelAsync(searchModel);
            return Json(model);
        }
        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManageShippingSettings))
                return await AccessDeniedDataTablesJson();

            var pickupPoint = await _recentViewService.GetRecentRecordproductByIdAsync(id);
            if (pickupPoint == null)
                return RedirectToAction("Configure");
            await _recentViewService.DeleteStorePickupPointAsync(pickupPoint);

            return new NullJsonResult();
        }
    }
}
    