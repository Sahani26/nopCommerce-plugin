﻿using Nop.Core;
using Nop.Plugin.Misc.Slick.Slider.Components;
using Nop.Services.Cms;
using Nop.Services.Plugins;
using Nop.Web.Framework.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.Slick.Slider
{
    public class SlickSliderPlugin :BasePlugin,IWidgetPlugin
    {
        private readonly IWebHelper _webHelper;

        public SlickSliderPlugin(IWebHelper webHelper)
        {
            _webHelper = webHelper;
        }

        public bool HideInWidgetList =>false;

        public override string GetConfigurationPageUrl()
        {

            return _webHelper.GetStoreLocation() + "Admin/PhotoUpload/Upload";
        }

        public Type GetWidgetViewComponent(string widgetZone)
        {
            return typeof(PhotoUploadViewComponent);
        }

        public Task<IList<string>> GetWidgetZonesAsync()
        {
            return Task.FromResult<IList<string>>(new List<string> { PublicWidgetZones.HomepageBeforeCategories });
        }

        public override Task InstallAsync()
        {
            return base.InstallAsync(); 
        }
        public override Task UninstallAsync() {     
            return base.UninstallAsync(); }
    }
}
