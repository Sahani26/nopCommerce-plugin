﻿using Nop.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.Slick.Slider.Domian
{
    public class PhotoUpload : BaseEntity
    {
        public string FileName { get; set; } // Original file name
        public string FilePath { get; set; } // Path to store the image
        public string MimeType { get; set; } // Image type (e.g., "image/png")
        public int FileSize { get; set; } // File size in bytes
        public DateTime CreatedOnUtc { get; set; } // Upload date
    }
}
