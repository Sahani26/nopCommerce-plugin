﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Nop.Web.Framework.Mvc.Routing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.Slick.Slider.Infrastructure
{
    public class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(IEndpointRouteBuilder endpointRouteBuilder)
        {
            endpointRouteBuilder.MapControllerRoute(
                name: "PhotoUploadList",
                pattern: "Admin/PhotoUpload/List",
                defaults: new { controller = "PhotoUpload", action = "List" }
            );

            endpointRouteBuilder.MapControllerRoute(
                name: "PhotoUpload",
                pattern: "Admin/PhotoUpload/Upload",
                defaults: new { controller = "PhotoUpload", action = "Upload" }
            );
        }

        public int Priority => 0;
    }
}
