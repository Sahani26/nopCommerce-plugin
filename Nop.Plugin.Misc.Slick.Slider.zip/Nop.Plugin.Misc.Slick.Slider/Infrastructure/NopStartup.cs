﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nop.Core.Infrastructure;
using Nop.Plugin.Misc.Slick.Slider.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.Slick.Slider.Infrastructure
{
    public class NopStartup : INopStartup
    {


        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            // Override the default ProductController with our custom one
            services.AddScoped<IPhotoUploadService, PhotoUploadService>();
        }
        public void Configure(IApplicationBuilder application)
        {
            // No middleware needed
        }



        public int Order =>1001;
    }
}
