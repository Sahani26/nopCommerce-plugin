﻿using FluentMigrator;
using Nop.Data.Extensions;
using Nop.Data.Migrations;
using Nop.Plugin.Misc.Slick.Slider.Domian;

namespace Nop.Plugin.Misc.Zettle.Data;

[NopMigration("2022/09/16 12:10:00", "Misc.Slick.Slider base schema", MigrationProcessType.Installation)]
public class SchemaMigration : AutoReversingMigration
{
    #region Methods

    /// <summary>
    /// Collect the UP migration expressions
    /// </summary>
    public override void Up()
    {
        Create.TableFor<PhotoUpload>();
    }

    #endregion
}