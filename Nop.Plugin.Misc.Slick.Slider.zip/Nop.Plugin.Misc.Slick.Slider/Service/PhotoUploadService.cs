﻿using Nop.Data;
using Nop.Plugin.Misc.Slick.Slider.Domian;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.Slick.Slider.Service
{
    public class PhotoUploadService : IPhotoUploadService
    {
        private readonly IRepository<PhotoUpload> _photoRepository;

        public PhotoUploadService(IRepository<PhotoUpload> photoRepository)
        {
            _photoRepository = photoRepository;
        }

        public async Task InsertPhotoAsync(PhotoUpload photo)
        {
            await _photoRepository.InsertAsync(photo);
        }

        public async Task DeletePhotoAsync(PhotoUpload photo)
        {
            await _photoRepository.DeleteAsync(photo);
        }

        public async Task<PhotoUpload> GetPhotoByIdAsync(int id)
        {
            return await _photoRepository.GetByIdAsync(id);
        }

        public async Task<IList<PhotoUpload>> GetAllPhotosAsync()
        {
            return await _photoRepository.Table.ToListAsync();
        }
    }
}
