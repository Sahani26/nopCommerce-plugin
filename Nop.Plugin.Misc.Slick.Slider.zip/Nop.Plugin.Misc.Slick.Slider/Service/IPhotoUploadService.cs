﻿using Nop.Plugin.Misc.Slick.Slider.Domian;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.Slick.Slider.Service
{
    public interface IPhotoUploadService
    {
        Task InsertPhotoAsync(PhotoUpload photo);
        Task DeletePhotoAsync(PhotoUpload photo);
        Task<PhotoUpload> GetPhotoByIdAsync(int id);
        Task<IList<PhotoUpload>> GetAllPhotosAsync();
    }
}
