﻿using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Misc.Slick.Slider.Service;
using Nop.Web.Framework.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.Slick.Slider.Components
{
    [ViewComponent(Name = "PhotoUpload")]
    public class PhotoUploadViewComponent :NopViewComponent
    {
    
       
            private readonly IPhotoUploadService _photoUploadService;

            public PhotoUploadViewComponent(IPhotoUploadService photoUploadService)
            {
                _photoUploadService = photoUploadService;
            }

            public async Task<IViewComponentResult> InvokeAsync()
            {
                var photos = await _photoUploadService.GetAllPhotosAsync();
                return View("~/Plugins/Misc.Slick.Slider/Views/List.cshtml", photos);
            }
        
    }
}
