﻿using DocumentFormat.OpenXml.Drawing.Charts;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Misc.Slick.Slider.Domian;
using Nop.Plugin.Misc.Slick.Slider.Service;
using Nop.Services.Media;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.Slick.Slider.Controllers
{
    [AutoValidateAntiforgeryToken] 
    [AuthorizeAdmin] //confirms access to the admin panel
    [Area(AreaNames.ADMIN)] //specifies the area containing a controller or action
    public class PhotoUploadController : BasePluginController
    {
        private readonly IPhotoUploadService _photoUploadService;
        private readonly IPictureService _pictureService;

        public PhotoUploadController(IPhotoUploadService photoUploadService, IPictureService pictureService)
        {
            _photoUploadService = photoUploadService;
            _pictureService = pictureService;
        }

        public async Task<IActionResult> List()
        {
            var photos = await _photoUploadService.GetAllPhotosAsync();
            return View("~/Plugins/Misc.Slick.Slider/Views/List.cshtml", photos);
        }

        [HttpGet]
        public async Task<IActionResult> Upload()
        {
            var photos = await _photoUploadService.GetAllPhotosAsync();
            return View("~/Plugins/Misc.Slick.Slider/Views/Upload.cshtml", photos);
        }
        [HttpPost]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                TempData["Error"] = "Please select a file to upload.";
                return RedirectToAction("Upload");
            }

            try
            {
                var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");

                // ✅ Ensure the uploads directory exists
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                var fileName = Path.GetFileName(file.FileName);
                var filePath = Path.Combine(uploadsFolder, fileName);

                // ✅ Save the file
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                // ✅ Save file details in the database
                var photo = new PhotoUpload
                {
                    FileName = fileName,
                    FilePath = "/uploads/" + fileName, // Relative path for display
                    MimeType = file.ContentType,
                    FileSize = (int)file.Length,
                    CreatedOnUtc = DateTime.UtcNow
                };

                await _photoUploadService.InsertPhotoAsync(photo);

                TempData["Success"] = "Photo uploaded successfully.";
                return RedirectToAction("Upload");
            }
            catch (Exception ex)
            {
                TempData["Error"] = "Error uploading photo: " + ex.Message;
                return RedirectToAction("Upload");
            }
        }


        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var photo = await _photoUploadService.GetPhotoByIdAsync(id);
                if (photo == null)
                {
                    TempData["Error"] = "Photo not found.";
                    return RedirectToAction("Upload");
                }

                // Delete the image file from the server
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", photo.FilePath.TrimStart('/'));
                if (System.IO.File.Exists(filePath))
                {
                    System.IO.File.Delete(filePath);
                }

                // Delete from database
                await _photoUploadService.DeletePhotoAsync(photo);

                TempData["Success"] = "Photo deleted successfully.";
            }
            catch (Exception ex)
            {
                TempData["Error"] = "Error deleting photo: " + ex.Message;
            }

            return RedirectToAction("Upload");
        }

    }
}
