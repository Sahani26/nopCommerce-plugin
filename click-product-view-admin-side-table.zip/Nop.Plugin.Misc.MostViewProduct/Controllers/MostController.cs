﻿using DocumentFormat.OpenXml.Drawing.Charts;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.AspNetCore.Mvc;
using Nop.Core.Domain.Common;
using Nop.Plugin.Misc.MostViewProduct.Factories;
using Nop.Plugin.Misc.MostViewProduct.Models;
using Nop.Plugin.Misc.MostViewProduct.Services;
using Nop.Services.Common;
using Nop.Services.Directory;
using Nop.Services.Localization;
using Nop.Services.Plugins;
using Nop.Services.Security;
using Nop.Services.Stores;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc;
using Nop.Web.Framework.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.MostViewProduct.Controllers
{
    [Area(AreaNames.ADMIN)]
    [AuthorizeAdmin]
    [AutoValidateAntiforgeryToken]
    public class MostController: BasePluginController
    {
        protected readonly IAddressService _addressService;
        protected readonly ICountryService _countryService;
        protected readonly ILocalizationService _localizationService;
        protected readonly IPermissionService _permissionService;
        protected readonly IStateProvinceService _stateProvinceService; 
        protected readonly IStoreService _storeService;
        protected readonly AddressSettings _addressSettings;
        protected readonly IMostViewModelFactory _mostViewModelFactory;
        protected readonly IMostViewService _mostViewService;

        public MostController(IAddressService addressService, ICountryService countryService, ILocalizationService localizationService, IPermissionService permissionService, IStateProvinceService stateProvinceService, IStoreService storeService, AddressSettings addressSettings, IMostViewModelFactory mostViewModelFactory, IMostViewService mostViewService)
        {
            _addressService = addressService;
            _countryService = countryService;
            _localizationService = localizationService;
            _permissionService = permissionService;
            _stateProvinceService = stateProvinceService;
            _storeService = storeService;
            _addressSettings = addressSettings;
            _mostViewModelFactory = mostViewModelFactory;
            _mostViewService = mostViewService;
        }

        public async Task<IActionResult> Configure()
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManageShippingSettings))
                return AccessDeniedView();

            //prepare model
            //prepare model
            var model = await _mostViewModelFactory.PrepareStorePickupPointSearchModelAsync(new MostViewSearchModel());

            return View("~/Plugins/Misc.MostViewProduct/Views/Configure.cshtml", model);
        }


        [HttpPost]
        public async Task<IActionResult> List(MostViewSearchModel searchModel)
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManageShippingSettings))
                return await AccessDeniedDataTablesJson();

            //prepare model
            var model = await _mostViewModelFactory.PrepareStorePickupPointListModelAsync(searchModel);

            return Json(model);
        }


        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManageShippingSettings))
                return await AccessDeniedDataTablesJson();

            var pickupPoint = await _mostViewService.GetStorePickupPointByIdAsync(id);
            if (pickupPoint == null)
                return RedirectToAction("Configure");
        

        /*    var address = await _addressService.GetAddressByIdAsync(pickupPoint.AddressId);
            if (address != null)
                await _addressService.DeleteAddressAsync(address);*/

            await _mostViewService.DeleteStorePickupPointAsync(pickupPoint);

            return new NullJsonResult();
        }


    }
}
