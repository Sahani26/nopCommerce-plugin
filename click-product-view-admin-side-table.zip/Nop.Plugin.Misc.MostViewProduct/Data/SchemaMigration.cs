﻿using FluentMigrator;
using Nop.Data.Extensions;
using Nop.Data.Migrations;
using Nop.Plugin.Misc.MostViewProduct.Domain; 

namespace Nop.Plugin.Misc.MostViewProduct.Data;

[NopMigration("2024/09/15 12:00:00", "Misc.MostViewProduct base schema", MigrationProcessType.Installation)]
public class SchemaMigration : AutoReversingMigration
{
    #region Methods

    /// <summary>
    /// Collect the UP migration expressions
    /// </summary>
    public override void Up()
    {
        Create.TableFor<MostRecord>();
    }

    #endregion
}