﻿using Nop.Core;
using Nop.Services.Plugins;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.MostViewProduct
{
    public class MostViewProductPlugin :BasePlugin
    {
        protected readonly IWebHelper _webHelper;

        public MostViewProductPlugin(IWebHelper webHelper)
        {
            _webHelper = webHelper;
        }

        public override string GetConfigurationPageUrl()
        {
            return $"{_webHelper.GetStoreLocation()}Admin/Most/Configure";
        }

        public override Task InstallAsync()
        {
            return base.InstallAsync();
        }
        public override Task UninstallAsync() {     return base.UninstallAsync(); }
    }
}
