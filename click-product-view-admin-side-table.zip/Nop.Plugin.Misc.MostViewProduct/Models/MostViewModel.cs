﻿using Nop.Web.Areas.Admin.Models.Catalog;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.MostViewProduct.Models
{
    public record MostViewModel :BaseNopEntityModel
    {
        [NopResourceDisplayName("Plugins.Pickup.PickupInStore.Fields.ProductId")]
        public int ProductId { get; set; }
        [NopResourceDisplayName("Plugins.Pickup.PickupInStore.Fields.ViewCount")]
        public int ViewCount { get; set; }
        [NopResourceDisplayName("Plugins.Pickup.PickupInStore.Fields.CustomerId")]
        public int CustomerId { get; set; }
        [NopResourceDisplayName("Plugins.Pickup.PickupInStore.Fields.CategoryId")]
        public int CategoryId { get; set; }
        [NopResourceDisplayName("Plugins.Pickup.PickupInStore.Fields.Name")]
        public string Name { get; set; }
        [NopResourceDisplayName("Plugins.Pickup.PickupInStore.Fields.StoreName")]
        public int StoreName { get; set; }
        public string PictureThumbnailUrl { get; set; } = string.Empty;
        public IList<ProductPictureModel> ProductPictureModels { get; set; } = new List<ProductPictureModel>();
        public string ProductSku { get; set; } // Add this
        public string ProductName { get; set; } // Add this

    }
}
