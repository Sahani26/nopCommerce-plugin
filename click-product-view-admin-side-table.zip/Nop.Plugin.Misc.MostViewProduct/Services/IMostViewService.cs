﻿using Nop.Core;
using Nop.Plugin.Misc.MostViewProduct.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.MostViewProduct.Services
{
    public interface IMostViewService
    {
        Task RecordProductViewAsync(int productId, int customerId, int categoryId);
        Task<IPagedList<MostRecord>> GetAllStorePickupPointsAsync( int pageIndex = 0, int pageSize = int.MaxValue);
        Task<MostRecord> GetStorePickupPointByIdAsync(int Id);

        Task DeleteStorePickupPointAsync(MostRecord pickupPoint);

    }
}
