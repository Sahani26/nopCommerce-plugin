﻿using Microsoft.AspNetCore.Routing;
using Nop.Services.Directory;
using Nop.Services.Plugins;
using Nop.Web.Framework.Menu;
using System.Linq;
using System.Threading.Tasks;

namespace Nop.Plugin.Widgets.PrintCurrencies
{
    public class PrintCurrenciesPlugin : BasePlugin, IAdminMenuPlugin
    {
        private readonly ICurrencyService _currencyService;

        public PrintCurrenciesPlugin(ICurrencyService currencyService)
        {
            _currencyService = currencyService;
        }

        public override string GetConfigurationPageUrl()
        {
            return "/Admin/PrintCurrencies/Index";
        }

        public async Task ManageSiteMapAsync(SiteMapNode rootNode)
        {
            var menuItem = new SiteMapNode()
            {
                SystemName = "PrintCurrencies",
                Title = "Print Currencies",
                ControllerName = "PrintCurrencies",
                ActionName = "Index",
                Visible = true,
                RouteValues = new RouteValueDictionary { { "area", "Admin" } },
            };

            var pluginNode = rootNode.ChildNodes.FirstOrDefault(x => x.SystemName == "Miscellaneous");
            if (pluginNode != null)
                pluginNode.ChildNodes.Add(menuItem);
            else
                rootNode.ChildNodes.Add(menuItem);
        }

        public override Task InstallAsync()
        {
            return base.InstallAsync();
        }

        public override Task UninstallAsync()
        {
            return base.UninstallAsync();
        }
    }
}
