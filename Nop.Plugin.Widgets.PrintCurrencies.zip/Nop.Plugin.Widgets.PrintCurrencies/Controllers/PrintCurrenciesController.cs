﻿using DocumentFormat.OpenXml.Drawing.Charts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nop.Services.Directory;
using Nop.Web.Framework.Controllers;
using System.Linq;
using System.Threading.Tasks;

namespace Nop.Plugin.Widgets.PrintCurrencies.Controllers
{
    [Route("Admin/PrintCurrencies")]
    public class PrintCurrenciesController : BasePluginController
    {
        private readonly ICurrencyService _currencyService;

        public PrintCurrenciesController(ICurrencyService currencyService)
        {
            _currencyService = currencyService;
        }

        [HttpGet("Index")]
        public async Task<IActionResult> Index()
        {
            var currencies = (await _currencyService.GetAllCurrenciesAsync()).Select(c => c.Name).ToList();
            return View("~/Plugins/Widgets.PrintCurrencies/Views/PrintCurrencies/Index.cshtml", currencies);
        }
    }
}
